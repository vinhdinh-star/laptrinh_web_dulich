<?php
    include_once '../server/server_VeMayBay2.php';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Kết Quả Tìm Vé Máy Bay</title>
    <link rel="stylesheet" href="../css/css_timvemaybay-form2.css" /> 
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>

</head>
<body>
    <div class="results-container">
        <form action="xacnhan_datve.php" method="post">
        <h2>Kết Quả Tìm Kiếm Chuyến Bay</h2>

        <div class="search-info">
            Bạn đang tìm chuyến bay từ <?= htmlspecialchars($diadiem_tu) ?> đến <?= htmlspecialchars($diadiem_den) ?>
            với hạng ghế <?= htmlspecialchars($hang_ghe) ?>.
            Tổng cộng <?= htmlspecialchars($tong_so_hanh_khach) ?> hành khách.
        </div>

        <div class="flight-list">
            <?php if (!empty($chuyen_bay_phu_hop)): ?>
                <?php foreach ($chuyen_bay_phu_hop as $flight): ?>
                    <div class="flight-card">
                        <div class="flight-card-header">
                            <div class="airline-info">
                                <span><?= htmlspecialchars($flight['hang_bay']) ?></span>
                                <span class="flight-number"><?= htmlspecialchars($flight['ma_chuyen_bay']) ?></span>
                            </div>
                            <div class="seat-class">
                                Hạng ghế: <strong><?= htmlspecialchars($flight['hang_ghe']) ?></strong>
                            </div>
                        </div>

                        <div class="flight-card-details">
                            <div class="flight-detail-item">
                                <div class="time"><?= htmlspecialchars(substr($flight['gio_di'], 0, 5)) ?></div>
                                <div class="location"><?= htmlspecialchars($flight['diadiem_tu']) ?></div>
                                <div class="date"><?= htmlspecialchars(date('d/m', strtotime($flight['ngay_di']))) ?></div>
                            </div>
                            <div class="flight-detail-item">
                                <i class="bx bx-right-arrow-alt"></i> <div class="duration">
                                    <?php
                                    $time1 = new DateTime($flight['gio_di']);
                                    $time2 = new DateTime($flight['gio_den']);
                                    $interval = $time1->diff($time2);
                                    echo $interval->format('%hh %im');
                                    ?>
                                </div>
                            </div>
                            <div class="flight-detail-item">
                                <div class="time"><?= htmlspecialchars(substr($flight['gio_den'], 0, 5)) ?></div>
                                <div class="location"><?= htmlspecialchars($flight['diadiem_den']) ?></div>
                                <div class="date"><?= htmlspecialchars(date('d/m', strtotime($flight['ngay_di']))) ?></div>
                            </div>
                        </div>

                        <div class="flight-card-footer">
                            <div class="price">
                                <?= number_format($flight['gia_ve'] * $tong_so_hanh_khach, 0, ',', '.') ?> VNĐ
                                <br>
                                <small>(Giá/người: <?= number_format($flight['gia_ve'], 0, ',', '.') ?> VNĐ)</small>
                            </div>
                            <a href="xacnhan_datve.php?flight_id=<?= $flight['id'] ?>&adults=<?= $so_luong_nguoi_lon ?>&children=<?= $so_luong_tre_em ?>" class="book-button">Đặt vé</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-flights">
                    Không tìm thấy chuyến bay nào phù hợp với tiêu chí của bạn. Vui lòng thử lại.
                </div>
            <?php endif; ?>
        </div>

        <a href="timvemaybay-form1.php" class="back-button">Quay lại tìm kiếm</a>
      </form>
    </div>
</body>
</html>