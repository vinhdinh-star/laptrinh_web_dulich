<?php
    include_once '../server/server_VeMayBay3.php';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Xác Nhận Đặt Vé</title>
    <link rel="stylesheet" href="../css/css_xacnhan_datve.css" /> 
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
</head>
<body>
    <div class="confirm-container">
        <h2>Xác Nhận Thông Tin Đặt Vé</h2>

        <?php if ($error_message): ?>
            <div class="alert-error"><?= htmlspecialchars($error_message) ?></div>
            <a href="timvemaybay-form1.php" class="back-link">Quay lại tìm kiếm</a>
        <?php elseif ($success_message): ?>
            <div class="alert-success"><?= htmlspecialchars($success_message) ?></div>
            <a href="timvemaybay-form1.php" class="back-link">Tiếp tục tìm kiếm chuyến bay khác</a>
            <?php elseif ($chuyen_bay_detail): ?>
            <div class="flight-summary">
                <h3>Chi tiết chuyến bay đã chọn</h3>
                <p><strong>Mã chuyến bay:</strong> <?= htmlspecialchars($chuyen_bay_detail['ma_chuyen_bay']) ?></p>
                <p><strong>Hãng bay:</strong> <?= htmlspecialchars($chuyen_bay_detail['hang_bay']) ?></p>
                <p><strong>Từ:</strong> <?= htmlspecialchars($chuyen_bay_detail['diadiem_tu']) ?> 
                   <strong>Đến:</strong> <?= htmlspecialchars($chuyen_bay_detail['diadiem_den']) ?></p>
                <p><strong>Ngày đi:</strong> <?= htmlspecialchars(date('d/m/Y', strtotime($chuyen_bay_detail['ngay_di']))) ?></p>
                <p><strong>Giờ bay:</strong> <?= htmlspecialchars(substr($chuyen_bay_detail['gio_di'], 0, 5)) ?> - <?= htmlspecialchars(substr($chuyen_bay_detail['gio_den'], 0, 5)) ?></p>
                <p><strong>Hạng ghế:</strong> <?= htmlspecialchars($chuyen_bay_detail['hang_ghe']) ?></p>
                <p><strong>Số lượng hành khách:</strong> Người lớn: <?= htmlspecialchars($adult_count) ?>, Trẻ em: <?= htmlspecialchars($child_count) ?></p>
                <p><strong>Tiện ích:</strong> <?= htmlspecialchars($chuyen_bay_detail['amenities'] ?: 'Không có') ?></p>
                <div class="total-price">
                    Tổng cộng: <?= number_format($chuyen_bay_detail['gia_ve'] * $tong_so_hanh_khach, 0, ',', '.') ?> VNĐ
                </div>
            </div>

            <form action="xacnhan_datve.php" method="post" class="passenger-info-form">
                <h3>Thông tin người đặt vé</h3>
                <div class="form-group">
                    <label for="hoten">Họ và Tên:</label>
                    <div class="input-icon">
                        <i class="bx bx-user"></i>
                        <input type="text" id="hoten" name="hoten" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="sodienthoai">Số điện thoại:</label>
                    <div class="input-icon">
                        <i class="bx bx-phone"></i>
                        <input type="tel" id="sodienthoai" name="sodienthoai" required pattern="[0-9]{10,11}" title="Vui lòng nhập số điện thoại hợp lệ (10 hoặc 11 chữ số)">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="cancuoccongdan">Số căn cước công dân:</label>
                    <div class="input-icon">
                        <i class="bx bx-id-card"></i>
                        <input type="text" id="cancuoccongdan" name="cancuoccongdan" required pattern="[0-9]{9,12}" title="Vui lòng nhập số CCCD hợp lệ (9 hoặc 12 chữ số)">
                    </div>
                </div>

                <input type="hidden" name="flight_id" value="<?= htmlspecialchars($chuyen_bay_detail['id']) ?>">
                <input type="hidden" name="adult_count" value="<?= htmlspecialchars($adult_count) ?>">
                <input type="hidden" name="child_count" value="<?= htmlspecialchars($child_count) ?>">

                <div class="form-submit">
                    <button type="submit" name="submit_datve">Xác nhận đặt vé</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>