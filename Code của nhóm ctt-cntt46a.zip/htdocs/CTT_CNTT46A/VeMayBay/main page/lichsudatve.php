<?php
session_start();
header('Content-Type: text/html; charset=utf-8'); 

$servername = "sql210.infinityfree.com";
$username = "if0_39115570";
$password = "nhomcttcntt46a";
$dbname = "if0_39115570_hotrodulich";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8mb4");

if ($conn->connect_error) {
    die("Kết nối database thất bại: " . $conn->connect_error);
}

if (!isset($_SESSION['id'])) {
        header("Location: ../../TrangChu/main page/formDangNhap.php");
        exit(); 
    }
$is_logged_in_lichsu = isset($_SESSION['id']) && isset($_SESSION['username']);
$username_lichsu = $is_logged_in_lichsu ? ($_SESSION['fullname'] ?? $_SESSION['username']) : '';

function getBookings($conn) {
    $bookings = [];
    $sql = "SELECT u.id, u.hoten, u.sodienthoai, u.cancuoccongdan, u.flight_id, u.ngay_dat_ve, u.so_luong_nguoi_lon, u.so_luong_tre_em, u.tong_gia, u.trang_thai,
                c.diadiem_tu, c.diadiem_den, c.gio_di, c.gio_den, c.ngay_di
            FROM usernguoidatve u 
            JOIN chuyenbay c ON u.flight_id = c.id
            where id_khachhang = ".$_SESSION['id']."
            ORDER BY u.ngay_dat_ve DESC";
   
    $result = $conn->query($sql);

    if ($result === false) {
        error_log("Lỗi truy vấn SQL khi lấy lịch sử đặt xe: " . $conn->error);
        return [];
    }

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
    }
    return $bookings;
}

if (isset($_POST['cancel_booking_id'])) {
    $booking_id_to_cancel = $_POST['cancel_booking_id'];
   
    $stmt = $conn->prepare("DELETE FROM usernguoidatve WHERE id = ?");
   
    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Lỗi prepare statement: ' . $conn->error]);
        $conn->close();
        exit();
    }
   
    $stmt->bind_param("i", $booking_id_to_cancel);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Hủy thành công!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Lỗi khi hủy đơn: ' . $stmt->error]);
    }
    $stmt->close();
    $conn->close();
    exit();
}

$bookings = getBookings($conn);
$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lịch sử đặt vé bay Quy Nhơn</title>
        <link rel="stylesheet" href="../css/css_lichsudatve.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    </head>
    <body>

    <header class="header">
        <div class="container">
            <a href="timvemaybay-form2.php" class="btn-back"><i class="fas fa-arrow-left"></i> Quay lại</a>
            <div></div>
        </div>
    </header>
    <div class="history-content container">
        <h2><i class="fas fa-history"></i> Lịch sử đặt vé của bạn</h2>

        <div id="booking-list-container" class="booking-list">
            <?php if (empty($bookings)): ?>
                <div id="no-history-message" class="no-history">
                    <p>Bạn chưa có vé nào được đặt.</p>
                    <p>Hãy <a href="timvemaybay-form1.php">đặt vé ngay</a> để bắt đầu hành trình!</p>
                </div>
            <?php else: ?>
                <?php foreach ($bookings as $booking): ?>
                    <div class="booking-card">
                        <div class="booking-details">
                        <p><strong>Tên người đặt vé:</strong> <?= htmlspecialchars($booking['hoten'] ?? 'Không rõ') ?></p>
                        <p><strong>Số điện thoại:</strong><?=htmlspecialchars($booking['sodienthoai'] ??'')?></p>
                        <p><strong>Từ:</strong> <?= htmlspecialchars($booking['diadiem_tu'] ?? '') ?> 
                        <strong>Đến:</strong> <?= htmlspecialchars($booking['diadiem_den']  ?? '') ?></p>
                        <p><strong>Giờ bay:</strong> <?= htmlspecialchars(substr($booking['gio_di'], 0, 5)) ?> - <?= htmlspecialchars(substr($booking['gio_den'], 0, 5)) ?></p>
                        <p><strong>Ngày đặt:</strong> <?= htmlspecialchars((new DateTime($booking['ngay_dat_ve'] ?? 'now'))->format('d/m/Y H:i')) ?></p>
                        <p><strong>Ngày đi:</strong> <?= htmlspecialchars(date('d/m/Y', strtotime($booking['ngay_di']))) ?></p>
                        <p><strong>Căn Cước Công Dân:</strong> <?= htmlspecialchars($booking['cancuoccongdan'] ?? '') ?></p>
                        <p><strong>Số lượng người lớn:</strong> <?= htmlspecialchars($booking['so_luong_nguoi_lon'] ?? '1') ?></p>
                        <p><strong>Số lượng trẻ em:</strong> <?= htmlspecialchars($booking['so_luong_tre_em'] ?? '0') ?></p>
                        <p class="price"><strong>Tổng Giá:</strong> <?= number_format($booking['tong_gia'] ?? 0, 0, ',', '.') ?> VND</p>
                    <div class="booking-actions">
                        <button class="btn-cancel-booking" data-id="<?= htmlspecialchars($booking['id'] ?? '') ?>">Hủy đơn</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
        </div>
    </div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const bookingListContainer = document.getElementById('booking-list-container');
        const noHistoryMessage = document.getElementById('no-history-message');

        function updateDisplay() {
            if (bookingListContainer.querySelectorAll('.booking-card').length === 0) {
                noHistoryMessage.style.display = 'block';
            } else {
                noHistoryMessage.style.display = 'none';
                bookingListContainer.style.display = 'grid';
            }
        }

        bookingListContainer.addEventListener('click', function(event) {
            if (event.target.classList.contains('btn-cancel-booking')) {
                const bookingIdToCancel = event.target.dataset.id;
                cancelBooking(bookingIdToCancel, event.target);
            }
        });

        function cancelBooking(id, buttonElement) {
            if (confirm('Bạn có chắc chắn muốn hủy không?')) {
                fetch('lichsudatve.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'cancel_booking_id=' + id
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        const bookingCard = buttonElement.closest('.booking-card');
                        if (bookingCard) {
                            bookingCard.remove();
                            updateDisplay();
                        }
                    } else {
                        alert('Lỗi: ' + data.message);
                    }
                });
            }
        }
        updateDisplay();
    });
</script>

</body>
</html>