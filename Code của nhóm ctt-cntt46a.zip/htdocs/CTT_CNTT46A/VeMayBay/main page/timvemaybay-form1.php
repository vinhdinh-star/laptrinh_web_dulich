<?php
    include_once "../server/server_VeMayBay.php";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Tìm Vé Máy Bay</title>
  <link rel="stylesheet" href="../css/css_timvemaybay-form1.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>

  <style>
    .back-button-ls {
    display: block;
    width: fit-content;
    margin: 20px auto 0;
    background-color: #fc1212;
    text-decoration: none;
    padding: 10px 20px;
    color: white;
    border-radius: 5px;
    text-align: center;
    transition: background-color 0.3s ease;
    }

    .back-button-ls:hover {
    background-color: #a51111;
    transform: scale(1.05);
    box-shadow: 0 6px 12px rgba(0,0,0,0.2);
    }
</style>

</head>
<body>
  <div id="form-container">
    <form id="input-airplane" action="timvemaybay-form2.php" method="post">
      <h2>Vé Máy Bay</h2>

      <!-- nơi xuất phát -->
      <div class="form-group">
        <label for="diadiem_tu">Nơi Bạn Xuất Phát Đến Quy Nhơn:</label>
        <div class="input-icon" style="position: relative;">
          <i class="bx bx-map"></i>
          <input 
            type="text" 
            id="diadiem_tu" 
            name="diadiem_tu" 
            onkeyup="filterDiaDiem()"
            required>
            <div id="diaDiemCon">
            </div>
        </div>
      </div>
        

        <!-- hạng ghế -->
        <div class="form-group">
            <label for="hangghe">Hạng ghế: </label>
            <div class="input-icon" style="position: relative;">
                <i class="bx bx-chair"></i>
                <input 
                type="text"
                id="hangghe"
                name="hangghe"
                onfocus="showSuggestions('hangghe')"
                oninput="filterSuggestions('hangghe')"
                autocomplete="off"
                required>
            <div class="suggestions-box" id="hangghe-suggestions">
              <div onclick="selectSuggestion('hangghe', 'Phổ thông')">Phổ thông</div>
              <div onclick="selectSuggestion('hangghe', 'Thương gia')">Thương gia</div>
              <div onclick="selectSuggestion('hangghe', 'Hạng nhất')">Hạng nhất</div>
            </div>
            </div>
        </div>


        <!-- Số hành khách -->
        <div class="form-group">
        <label for="sohangkhach-display">Số hành khách:</label>
        <div class="input-icon" style="position: relative;">
          <i class="bx bx-user"></i>
          <input 
            type="text" 
            id="sohangkhach-display" 
            name="sohangkhach_display"
            placeholder="Chọn số hành khách"
            readonly
            onclick="togglePassengerMenu()" />

          <input type="hidden" name="adult_count" id="adult-hidden" value="1" />
          <input type="hidden" name="child_count" id="child-hidden" value="0" />

          <div id="passenger-dropdown" class="passenger-dropdown">
            <div class="passenger-row">
              <span>Người lớn (≥16)</span>
              <button type="button" onclick="updatePassenger('adult', -1)">-</button>
              <span id="adult-count" class="count">1</span>
              <button type="button" onclick="updatePassenger('adult', 1)">+</button>
            </div>
            <div class="passenger-row">
              <span>Trẻ em (&lt;16)</span>
              <button type="button" onclick="updatePassenger('child', -1)">-</button>
              <span id="child-count" class="count">0</span>
              <button type="button" onclick="updatePassenger('child', 1)">+</button>
            </div>
            <div class="passenger-note">
              <small>Lưu ý: Tối đa 9 hành khách (bao gồm cả người lớn và trẻ em)</small>
            </div>
          </div>
        </div>
      </div>

       <!--tìm chuyến bay -->
      <div class="form-submit">
        <button type="submit">Tìm chuyến bay</button>
      </div>
      <a href="lichsudatve.php" class="back-button-ls"><i class="fas fa-history"></i>Lịch sử đặt vé </a>
    </form>
  </div>

  <script>
    const inputAirolane = document.getElementById("input-airplane");
    const diaDiemCon = document.getElementById("diaDiemCon");
    const diaDiem = document.getElementById("diadiem_tu");

    const diaDiemList = <?php echo isset($locations) && !empty($locations) ? json_encode(array_values($locations), JSON_UNESCAPED_UNICODE) : '["kết nối CSDL thất bại !"]'; ?>;

    function renderDiaDiemList() {
            diaDiemCon.innerHTML = "";
            diaDiemList.forEach((diaDiem) => {
              const btn = document.createElement("button");
              btn.className = "btnDiaDiem";
              btn.type = "button";
              btn.textContent = diaDiem;
              btn.onclick = () => chonDiaDiem(diaDiem);
              diaDiemCon.appendChild(btn);
            });
          }

    function filterDiaDiem() {
            const diaDiemInput = diaDiem.value.toLowerCase();
            const diaDiems = document.querySelectorAll(".btnDiaDiem");
            diaDiems.forEach((diadiem) => {
              const diaDiemName = diadiem.textContent.toLowerCase();
              diadiem.style.display = diaDiemName.includes(diaDiemInput) ? "block" : "none";
            });
          }


          function chonDiaDiem(diaDiem1) {
            if (!diaDiem) {
              console.error("Input #diadiem_tu not found");
              return;
            }
            diaDiem.value = diaDiem1;
            diaDiemCon.style.height = "0px";
            diaDiemCon.classList.remove("open");
            setTimeout(() => {
              diaDiemCon.style.padding = "0px";
            }, 200);
            a = 1;
          }

          let a = 1;

          diaDiem.addEventListener("click", function (e) {
            e.stopPropagation();
            if (a === 1) {
              diaDiemCon.style.height = "200px";
              diaDiemCon.classList.add("open");
              a = 0;
            } else {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });

          diaDiem.addEventListener("blur", function (e) {
            if (!e.relatedTarget || !diaDiemCon.contains(e.relatedTarget)) {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });

          diaDiem.addEventListener("keydown", function (e) {
            const diaDiems = Array.from(document.querySelectorAll(".btnDiaDiem:not([style*='display: none'])"));
            if (diaDiems.length === 0) return;

            let index = diaDiems.findIndex((btn) => btn.classList.contains("selected"));

            if (e.key === "ArrowDown") {
              e.preventDefault();
              if (index < diaDiems.length - 1) {
                if (index >= 0) diaDiems[index].classList.remove("selected");
                diaDiems[index + 1].classList.add("selected");
              }
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              if (index > 0) {
                diaDiems[index].classList.remove("selected");
                diaDiems[index - 1].classList.add("selected");
              }
            } else if (e.key === "Enter" && index >= 0) {
              e.preventDefault();
              chonDiaDiem(diaDiems[index].textContent);
            }
          });

          diaDiemCon.addEventListener("click", function (e) {
            e.stopPropagation();
          });

          renderDiaDiemList();


    const texts = <?php echo json_encode(array_values($text), JSON_UNESCAPED_UNICODE); ?>;

          let textIndex = 0;
          let charIndex = 0;
          let isDeleting = false;

          function loopPlaceholders() {
            if (diaDiem.value.length > 0) {
              setTimeout(loopPlaceholders, 100);
              return;
            }
            const currentText = texts[textIndex];
            const currentSubstring = currentText.substring(0, charIndex);
            diaDiem.setAttribute("placeholder", currentSubstring);

            if (!isDeleting) {
              charIndex++;
              if (charIndex > currentText.length) {
                isDeleting = true;
                setTimeout(loopPlaceholders, 1500);
                return;
              }
            } else {
              charIndex--;
              if (charIndex < 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
              }
            }
            setTimeout(loopPlaceholders, isDeleting ? 50 : 100);
          }

          loopPlaceholders();
          //--------------------------------------

    function showSuggestions(id) {
      const box = document.getElementById(id + '-suggestions');
      if (box) box.style.display = 'block';
    }

    function filterSuggestions(id) {
      const input = document.getElementById(id).value.toLowerCase();
      const box = document.getElementById(id + '-suggestions');
      const suggestions = box.querySelectorAll('div');

      suggestions.forEach(item => {
        item.style.display = item.innerText.toLowerCase().includes(input) ? 'block' : 'none';
      });

      box.style.display = input.trim() === "" ? "none" : "block";
    }

    function selectSuggestion(id, value) {
      const input = document.getElementById(id);
      const box = document.getElementById(id + '-suggestions');

      if (input) input.value = value;
      if (box) box.style.display = 'none';
    }

    document.addEventListener('click', function (e) {
    document.querySelectorAll('.suggestions-box').forEach(box => {
      if (!box.contains(e.target) && !box.previousElementSibling.contains(e.target)) {
        box.style.display = 'none';
      }
    });
      const dropdown = document.getElementById("passenger-dropdown");
      const input = document.getElementById("sohangkhach-display");
      if (!dropdown.contains(e.target) && !input.contains(e.target)) {
        dropdown.style.display = "none";
      }
    });

    let adultCount = 1;
    let childCount = 0;

    function togglePassengerMenu() {
      const dropdown = document.getElementById("passenger-dropdown");
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    function updatePassenger(type, change) {
      const total = adultCount + childCount + change;

      if (type === "adult") {
        if (adultCount + change >= 1 && total <= 9) adultCount += change;
      } else if (type === "child") {
        if (childCount + change >= 0 && total <= 9) childCount += change;
      }

      document.getElementById("adult-count").innerText = adultCount;
      document.getElementById("child-count").innerText = childCount;
      updatePassengerDisplay();
    }

    function updatePassengerDisplay() {
      const display = document.getElementById("sohangkhach-display");
      display.value = `${adultCount} người lớn, ${childCount} trẻ em`;
      document.getElementById("adult-hidden").value = adultCount;
      document.getElementById("child-hidden").value = childCount;
    }

    updatePassengerDisplay();


    function debounce(func, wait) {
    let timeout;
    return function(...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }

  async function fetchSanBaySuggestions(id) {
    const input = document.getElementById(id);
    const term = input.value.trim();
    const box = document.getElementById(id + '-suggestions');
    if (!term) {
      box.style.display = 'none';
      return;
    }
    try {
      const res = await fetch(`getSanBay.php?term=${encodeURIComponent(term)}`);
      const data = await res.json();

      box.innerHTML = '';
      if (data.length > 0) {
        data.forEach(item => {
          const div = document.createElement('div');
          div.textContent = item.label;
          div.onclick = () => {
            input.value = item.value;
            box.style.display = 'none';
          };
          box.appendChild(div);
        });
        box.style.display = 'block';
      } else {
        box.style.display = 'none';
      }
    } catch (error) {
      console.error('Lỗi lấy gợi ý sân bay:', error);
      box.style.display = 'none';
    }
  }

  const debouncedFetchTu = debounce(() => fetchSanBaySuggestions('diadiem_tu'), 300);
  const debouncedFetchDen = debounce(() => fetchSanBaySuggestions('diadiem_den'), 300);

  document.getElementById('diadiem_tu').addEventListener('input', debouncedFetchTu);
    </script>
</body>
</html>

