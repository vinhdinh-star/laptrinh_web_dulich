<?php 
    include_once "../connect/connect.php"; 

    $sql = "SELECT DISTINCT diadiem_tu FROM chuyenbay WHERE diadiem_den = 'Quy Nhơn'";
    $stmt = $pdo->query($sql);

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $locations = [];

    foreach ($results as $row) 
    {
        $locations[] = $row['diadiem_tu'];
    }

    $text = $locations; 
    $text[] = "Lựa Chọn Nơi Bạn Xuất Phát ?"; 
    
    $locations = array_unique($locations);
    $text = array_unique($text);
?>