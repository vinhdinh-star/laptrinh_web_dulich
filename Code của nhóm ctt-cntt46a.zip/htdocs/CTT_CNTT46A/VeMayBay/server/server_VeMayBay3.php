<?php
error_reporting(E_ALL); // Luôn bật để debug
ini_set('display_errors', 1);
session_start();
    

include_once '../connect/connect.php'; 

$flight_id = null;
$adult_count = 1;
$child_count = 0;
$id = $_SESSION['id'];

// Khởi tạo biến để tránh lỗi undefined
$chuyen_bay_detail = null;
$error_message = "";
$success_message = "";

// XỬ LÝ KHI FORM XÁC NHẬN ĐƯỢC GỬI (POST) ĐƯỢC ƯU TIÊN KIỂM TRA TRƯỚC
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_datve'])) {

    // Lấy thông tin từ form POST
    $flight_id = $_POST['flight_id'] ?? null; // Lấy flight_id từ POST
    $adult_count = intval($_POST['adult_count'] ?? 1); // Lấy adult_count từ POST
    $child_count = intval($_POST['child_count'] ?? 0); // Lấy child_count từ POST

    $hoten = $_POST['hoten'] ?? '';
    $sodienthoai = $_POST['sodienthoai'] ?? '';
    $cancuoccongdan = $_POST['cancuoccongdan'] ?? '';
    $tong_so_hanh_khach = $adult_count + $child_count;

    // Validate thông tin người đặt
    if (empty($hoten) || empty($sodienthoai) || empty($cancuoccongdan) || !$flight_id) {
        $error_message = "Vui lòng điền đầy đủ thông tin cá nhân và đảm bảo chuyến bay hợp lệ.";
    } else {
        try {
            // Lấy lại chi tiết chuyến bay để tính toán giá và kiểm tra số lượng vé cuối cùng trước khi đặt
            $sql_get_flight_check = "SELECT * FROM chuyenbay WHERE id = :flight_id";
            $stmt_get_flight_check = $pdo->prepare($sql_get_flight_check);
            $stmt_get_flight_check->bindParam(':flight_id', $flight_id, PDO::PARAM_INT);
            $stmt_get_flight_check->execute();
            $current_flight_detail = $stmt_get_flight_check->fetch(PDO::FETCH_ASSOC);

            if (!$current_flight_detail || $current_flight_detail['so_luong_ve'] < $tong_so_hanh_khach) {
                $error_message = "Chuyến bay không còn đủ vé hoặc không tồn tại. Vui lòng kiểm tra lại.";
                // Quan trọng: Nếu không đủ vé, bạn có thể muốn giữ lại chi tiết chuyến bay để hiển thị lỗi mà không chuyển hướng
                $chuyen_bay_detail = $current_flight_detail; // Giữ lại thông tin để hiển thị trên form nếu có lỗi
            } else {
                $gia_ve_co_ban = $current_flight_detail['gia_ve'];
                $tong_gia_don_hang = $gia_ve_co_ban * $tong_so_hanh_khach;

                // Bắt đầu giao dịch (Transaction) để đảm bảo tính toàn vẹn dữ liệu
                $pdo->beginTransaction();

                // 1. Chèn dữ liệu vào bảng usernguoidatve
                $sql_insert_datve = "INSERT INTO usernguoidatve (hoten, sodienthoai, cancuoccongdan, flight_id, so_luong_nguoi_lon, so_luong_tre_em, tong_gia, trang_thai, id_khachhang)
                                     VALUES (:hoten, :sodienthoai, :cancuoccongdan, :flight_id, :so_luong_nguoi_lon, :so_luong_tre_em, :tong_gia, 'Chờ xác nhận', :id)";
                $stmt_insert_datve = $pdo->prepare($sql_insert_datve);
                $stmt_insert_datve->bindParam(':hoten', $hoten);
                $stmt_insert_datve->bindParam(':sodienthoai', $sodienthoai);
                $stmt_insert_datve->bindParam(':cancuoccongdan', $cancuoccongdan);
                $stmt_insert_datve->bindParam(':flight_id', $flight_id, PDO::PARAM_INT);
                $stmt_insert_datve->bindParam(':so_luong_nguoi_lon', $adult_count, PDO::PARAM_INT);
                $stmt_insert_datve->bindParam(':so_luong_tre_em', $child_count, PDO::PARAM_INT);
                $stmt_insert_datve->bindParam(':tong_gia', $tong_gia_don_hang);
                $stmt_insert_datve->bindParam(':id', $id);
                $stmt_insert_datve->execute();

                $last_inserted_id = $pdo->lastInsertId(); // Lấy ID của đơn đặt vé vừa tạo

                // 2. Cập nhật số lượng vé còn lại trong bảng chuyenbay
                $sql_update_ve = "UPDATE chuyenbay SET so_luong_ve = so_luong_ve - :so_luong_giam WHERE id = :flight_id";
                $stmt_update_ve = $pdo->prepare($sql_update_ve);
                $stmt_update_ve->bindParam(':so_luong_giam', $tong_so_hanh_khach, PDO::PARAM_INT);
                $stmt_update_ve->bindParam(':flight_id', $flight_id, PDO::PARAM_INT);
                $stmt_update_ve->execute();

                // Hoàn tất giao dịch
                $pdo->commit();
                $success_message = "Chúc mừng! Đơn đặt vé của bạn đã được ghi nhận. Mã đơn hàng của bạn là: " . $last_inserted_id . ". Vui lòng kiểm tra tin nhắn điện thoại để biết chi tiết.";

                // Tùy chọn: Sau khi thành công, bạn có thể chuyển hướng về trang lịch sử đặt vé hoặc trang thành công
                // để tránh submit lại form khi refresh
                // header("Location: dat_ve_thanh_cong.php?order_id=" . $last_inserted_id);
                // exit();

                // Nếu không chuyển hướng, cần đảm bảo các biến GET ban đầu không bị mất
                // hoặc hiển thị trạng thái thành công mà không cần lại chi tiết chuyến bay
                // Nếu muốn giữ lại thông tin chuyến bay trên màn hình sau thành công:
                $chuyen_bay_detail = $current_flight_detail;
            }
        } catch (PDOException $e) {
            // Rollback giao dịch nếu có lỗi xảy ra
            $pdo->rollBack();
            if ($e->getCode() == '23000') { // Mã lỗi cho Duplicate entry
                $error_message = "Số CCCD này đã được sử dụng để đặt vé. Vui lòng kiểm tra lại hoặc liên hệ hỗ trợ.";
            } else {
                $error_message = "Có lỗi xảy ra trong quá trình đặt vé. Vui lòng thử lại sau. (" . $e->getMessage() . ")";
            }
            // Giữ lại thông tin chuyến bay để hiển thị lỗi trên form
            // Nếu bạn đã lấy current_flight_detail ở trên
            // Nếu không, bạn cần lấy lại nó từ database dựa trên flight_id nếu muốn hiển thị chi tiết khi có lỗi CSDL.
        }
    }
}
// XỬ LÝ KHI NGƯỜI DÙNG TỪ FORM2 CHUYỂN SANG (GET) VÀ CHƯA CÓ LỖI HOẶC THÀNH CÔNG TỪ POST
// Hoặc khi có lỗi từ POST và muốn hiển thị lại form với chi tiết chuyến bay
// Quan trọng: Chỉ chạy phần này nếu chưa có thông báo thành công hoặc lỗi từ POST,
// hoặc nếu có lỗi từ POST và muốn hiển thị lại form.
if (!$success_message && !$error_message) { // Nếu chưa có thông báo thành công hoặc lỗi từ POST
    $flight_id = $_GET['flight_id'] ?? null; // Lấy từ GET khi trang load lần đầu
    $adult_count = intval($_GET['adults'] ?? 1);
    $child_count = intval($_GET['children'] ?? 0);
    $tong_so_hanh_khach = $adult_count + $child_count;

    if ($flight_id) {
        try {
            $sql_get_flight = "SELECT * FROM chuyenbay WHERE id = :flight_id";
            $stmt_get_flight = $pdo->prepare($sql_get_flight);
            $stmt_get_flight->bindParam(':flight_id', $flight_id, PDO::PARAM_INT);
            $stmt_get_flight->execute();
            $chuyen_bay_detail = $stmt_get_flight->fetch(PDO::FETCH_ASSOC);

            if (!$chuyen_bay_detail) {
                $error_message = "Không tìm thấy thông tin chuyến bay này.";
            } elseif ($chuyen_bay_detail['so_luong_ve'] < $tong_so_hanh_khach) {
                $error_message = "Số lượng vé còn lại không đủ cho số lượng hành khách bạn chọn. Vui lòng quay lại và chọn chuyến khác.";
                // Có thể chuyển hướng về trang tìm kiếm nếu không đủ vé, hoặc giữ lại lỗi
                header("Location: timvemaybay-form1.php?error=not_enough_tickets");
                exit();
            }
        } catch (PDOException $e) {
            $error_message = "Lỗi truy vấn CSDL khi lấy chi tiết chuyến bay: " . $e->getMessage();
        }
    } else {
        $error_message = "Không có thông tin chuyến bay được chọn.";
    }
} elseif ($error_message && $flight_id) { // Nếu có lỗi từ POST và flight_id vẫn còn
    // Lấy lại chi tiết chuyến bay để hiển thị form với lỗi
    try {
        $sql_get_flight = "SELECT * FROM chuyenbay WHERE id = :flight_id";
        $stmt_get_flight = $pdo->prepare($sql_get_flight);
        $stmt_get_flight->bindParam(':flight_id', $flight_id, PDO::PARAM_INT);
        $stmt_get_flight->execute();
        $chuyen_bay_detail = $stmt_get_flight->fetch(PDO::FETCH_ASSOC);

        // Đảm bảo $tong_so_hanh_khach cũng được xác định lại để hiển thị
        if (!isset($tong_so_hanh_khach)) {
            $tong_so_hanh_khach = $adult_count + $child_count;
        }

    } catch (PDOException $e) {
        // Cân nhắc xử lý lỗi này nếu không thể lấy lại chi tiết chuyến bay
        // Có thể để $chuyen_bay_detail là null và hiển thị thông báo lỗi chung
    }
}
?>