<?php
include_once '../connect/connect.php'; 
include_once '../server/server_VeMayBay.php'; 


session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

      if (!isset($_SESSION['username'])) {
        header("Location: ../../TrangChu/main page/formDangNhap.php");
        exit(); 
    } 
    
    $diadiem_tu = $_POST['diadiem_tu'] ?? '';
    $hang_ghe = $_POST['hangghe'] ?? '';
    $so_luong_nguoi_lon = intval($_POST['adult_count'] ?? 1);
    $so_luong_tre_em = intval($_POST['child_count'] ?? 0);
    $tong_so_hanh_khach = $so_luong_nguoi_lon + $so_luong_tre_em;

    $diadiem_den = 'Quy Nhơn'; 

    // Validate dữ liệu cơ bản (có thể thêm nhiều kiểm tra hơn)
    if (empty($diadiem_tu) || empty($hang_ghe) || $tong_so_hanh_khach <= 0) {
        header("Location: timvemaybay-form1.php?error=missing_info");
        exit();
    }

    $sql_tim_chuyen_bay = "SELECT * FROM chuyenbay
                          WHERE diadiem_tu = :diadiem_tu
                          AND diadiem_den = :diadiem_den
                          AND ngay_di >= CURDATE()
                          AND hang_ghe = :hang_ghe
                          AND so_luong_ve >= :so_luong_ve
                          ORDER BY ngay_di ASC, gio_di ASC"; // Sắp xếp theo ngay va giờ khởi hành


    try {
        $stmt = $pdo->prepare($sql_tim_chuyen_bay);

        // Bind các tham số để tránh SQL Injection
        $stmt->bindParam(':diadiem_tu', $diadiem_tu);
        $stmt->bindParam(':diadiem_den', $diadiem_den);
        $stmt->bindParam(':hang_ghe', $hang_ghe);
        $stmt->bindParam(':so_luong_ve', $tong_so_hanh_khach, PDO::PARAM_INT); // Đảm bảo kiểu số nguyên       

        $stmt->execute();
        $chuyen_bay_phu_hop = $stmt->fetchAll(PDO::FETCH_ASSOC);


    } catch (PDOException $e) {
        echo "Lỗi truy vấn: " . $e->getMessage();
        $chuyen_bay_phu_hop = []; 
    }
} else {
    header("Location: timvemaybay-form1.php");
    exit();
}
?>