INSERT INTO ChuyenBay (ma_chuyen_bay, hang_bay, diadiem_tu, diadiem_den, ngay_di, gio_di, gio_den, gia_ve, hang_ghe, so_luong_ve, amenities, thoi_gian_bay) VALUES
('VN1302', 'Vietnam Airlines', 'Đà Nẵng', 'Quy Nhơn', '2025-05-28', '09:00:00', '09:50:00', 950000, 'Phổ thông', 150, 'Hành lý 23kg', 'Sáng'),
('VJ240', 'VietJet Air', 'Đà Nẵng', 'Quy Nhơn', '2025-05-29', '14:30:00', '15:20:00', 700000, 'Phổ thông', 180, 'Hành lý xách tay 7kg', 'Chiều'),
('QH978', 'Bamboo Airways', 'Cần Thơ', 'Quy Nhơn', '2025-05-30', '07:45:00', '09:10:00', 1400000, 'Phổ thông', 80, 'Hành lý 15kg, Nước uống', 'Sáng'),
('VN1670', 'Vietnam Airlines', 'Cần Thơ', 'Quy Nhơn', '2025-05-31', '12:00:00', '13:25:00', 1700000, 'Phổ thông', 60, 'Hành lý 23kg, Suất ăn nhẹ', 'Trưa'),
('VJ406', 'VietJet Air', 'Hải Phòng', 'Quy Nhơn', '2025-06-01', '10:30:00', '12:00:00', 1650000, 'Phổ thông', 90, 'Hành lý xách tay 7kg', 'Sáng'),
('QH332', 'Bamboo Airways', 'Hải Phòng', 'Quy Nhơn', '2025-06-02', '18:00:00', '19:30:00', 1900000, 'Phổ thông', 75, 'Hành lý 15kg', 'Tối'),
('VN1550', 'Vietnam Airlines', 'Nha Trang', 'Quy Nhơn', '2025-06-03', '11:15:00', '12:05:00', 800000, 'Phổ thông', 100, 'Hành lý 23kg', 'Trưa'),
('VJ502', 'VietJet Air', 'Nha Trang', 'Quy Nhơn', '2025-06-04', '16:00:00', '16:55:00', 650000, 'Phổ thông', 130, 'Hành lý xách tay 7kg', 'Chiều'),
('QH776', 'Bamboo Airways', 'Huế', 'Quy Nhơn', '2025-06-05', '08:15:00', '09:10:00', 900000, 'Phổ thông', 110, 'Hành lý 15kg', 'Sáng'),
('VN1700', 'Vietnam Airlines', 'Huế', 'Quy Nhơn', '2025-06-07', '13:45:00', '14:40:00', 1100000, 'Phổ thông', 80, 'Hành lý 23kg', 'Chiều');
