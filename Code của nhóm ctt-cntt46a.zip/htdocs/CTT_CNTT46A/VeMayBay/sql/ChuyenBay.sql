CREATE TABLE chuyenbay (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_chuyen_bay VARCHAR(20) NOT NULL UNIQUE, 
    hang_bay VARCHAR(50) NOT NULL,           
    diadiem_tu VARCHAR(100) NOT NULL,         
    diadiem_den VARCHAR(100) NOT NULL,        
    ngay_di DATE NOT NULL,                    
    gio_di TIME NOT NULL,                     
    gio_den TIME NOT NULL,                    
    gia_ve DECIMAL(10, 0) NOT NULL,           
    hang_ghe ENUM('Phổ thông', 'Thương gia', 'Phổ thông đặc biệt') NOT NULL, 
    so_luong_ve INT NOT NULL,                  
    amenities TEXT,                           
    thoi_gian_bay VARCHAR(50)                  
);