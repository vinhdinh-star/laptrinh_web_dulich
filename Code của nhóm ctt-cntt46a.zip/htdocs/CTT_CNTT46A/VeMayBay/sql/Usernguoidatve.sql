CREATE TABLE usernguoidatve (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hoten VARCHAR(100) NOT NULL,              
    sodienthoai VARCHAR(20) NOT NULL,         
    cancuoccongdan VARCHAR(12) NOT NULL UNIQUE, 
    flight_id INT NOT NULL,                   
    ngay_dat_ve DATETIME DEFAULT CURRENT_TIMESTAMP, 
    so_luong_nguoi_lon INT NOT NULL DEFAULT 1, 
    so_luong_tre_em INT NOT NULL DEFAULT 0,   
    tong_gia DECIMAL(10, 0) NOT NULL,         
    trang_thai VARCHAR(50) DEFAULT 'Chờ xác nhận', 

    FOREIGN KEY (flight_id) REFERENCES chuyenbay(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);