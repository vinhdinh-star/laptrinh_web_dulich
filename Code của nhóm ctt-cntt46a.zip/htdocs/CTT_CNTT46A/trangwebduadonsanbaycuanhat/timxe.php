<?php
session_start();
require 'codephpcuatimxe.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tìm xe - Đưa đón sân bay Quy Nhơn</title>
    <link rel="stylesheet" href="csstimxe.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
</head>
<body>
<div class="search-summary-bar">
    <div class="container">
        <div class="search-info">
            <p><strong>Từ:</strong> <?= htmlspecialchars($pickup) ?> <i class="fas fa-arrow-right"></i> <strong>Đến:</strong> <?= htmlspecialchars($dropoff) ?></p>
            <p><i class="far fa-calendar-alt"></i> <?= htmlspecialchars($date) ?> <i class="far fa-clock" style="margin-left:15px;"></i> <?= htmlspecialchars($time) ?> <i class="fas fa-users" style="margin-left:15px;"></i> <?= htmlspecialchars($passengers) ?> khách</p>
        </div>
        <div class="summary-actions">
            <a href="lichsudatxe.php" class="btn btn-history"><i class="fas fa-history"></i> Lịch sử đặt xe</a>
            <a href="<?= htmlspecialchars($editSearchUrl) ?>" class="btn btn-edit-search"><i class="fas fa-pencil-alt"></i> Thay đổi</a>
        </div>
    </div>
</div>

<div class="main-content container">
    <aside class="filters-sidebar">
        <h3><i class="fas fa-filter"></i> Bộ lọc</h3>
        <form method="GET" action="timxe.php" id="filter-form">
            <input type="hidden" name="pickup" value="<?= htmlspecialchars($pickup) ?>">
            <input type="hidden" name="dropoff" value="<?= htmlspecialchars($dropoff) ?>">
            <input type="hidden" name="date" value="<?= htmlspecialchars($date) ?>">
            <input type="hidden" name="time" value="<?= htmlspecialchars($time) ?>">
            <input type="hidden" name="passengers" value="<?= htmlspecialchars($passengers) ?>">
            <input type="hidden" id="hidden_sort_by" name="sort_by" value="<?= htmlspecialchars($sort_by) ?>">

            <div class="filter-group">
                <label for="price-range">Giá tối đa:</label>
                <div class="price-range-container">
                    <input type="range" id="price-range" name="price_max" min="100000" max="2000000" step="10000" value="<?= htmlspecialchars($filter_price_max) ?>">
                    <output for="price-range" id="price-range-value">Đến <?= number_format($filter_price_max, 0, ',', '.') ?> VND</output>
                </div>
            </div>
            <div class="filter-group">
                <label for="car-type">Loại xe (Sức chứa):</label>
                <select id="car-type" name="car_type_capacity">
                    <option value="" <?= empty($filter_car_type_capacity) ? 'selected' : '' ?>>Tất cả loại xe</option>
                    <option value="2" <?= $filter_car_type_capacity == '2' ? 'selected' : '' ?>>Xe 2 chỗ</option>
					<option value="4" <?= $filter_car_type_capacity == '4' ? 'selected' : '' ?>>Xe 4 chỗ</option>
                    <option value="7" <?= $filter_car_type_capacity == '7' ? 'selected' : '' ?>>Xe 7 và 10 chỗ</option>
                    <option value="16" <?= $filter_car_type_capacity == '16' ? 'selected' : '' ?>>Xe 16 chỗ</option>
                    <option value="29" <?= $filter_car_type_capacity == '29' ? 'selected' : '' ?>>Xe 29 chỗ</option>
                    <option value="45" <?= $filter_car_type_capacity == '45' ? 'selected' : '' ?>>Xe 45 chỗ</option>
                </select>
            </div>
            <div class="filter-group">
                <label for="payment-method">Hình thức thanh toán:</label>
                <select id="payment-method" name="payment_method">
                    <option value="" <?= empty($filter_payment_method) ? 'selected' : '' ?>>Tất cả hình thức</option>
                    <option value="cash" <?= $filter_payment_method == 'cash' ? 'selected' : '' ?>>Tiền mặt</option>
                    <option value="transfer" <?= $filter_payment_method == 'transfer' ? 'selected' : '' ?>>Chuyển khoản</option>
                </select>
            </div>
            <button type="submit" class="btn btn-apply-filters"><i class="fas fa-check"></i> Áp dụng</button>
        </form>
    </aside>

    <div class="results-area">
        <div class="results-header">
            <h2>Tìm thấy <?= count($finalSuitableCars) ?> xe phù hợp</h2>
        </div>

        <?php if (!$validPickup || !$validDropoff): ?>
            <div class="no-result">
                <i class="fas fa-exclamation-triangle fa-3x"></i>
                <p>Thông tin tìm kiếm chưa đầy đủ.</p>
                <p>Vui lòng <a href="<?= htmlspecialchars($editSearchUrl) ?>">quay lại</a> và nhập đầy đủ điểm đón và điểm đến.</p>
            </div>
        <?php else:
            if (count($finalSuitableCars) === 0): ?>
                <div class="no-result">
                    <i class="fas fa-car-side fa-3x" style="color: #B0C4DE;"></i>
                    <p>Không tìm thấy xe nào phù hợp với yêu cầu của bạn.</p>
                    <?php
                        $changeFilterLink = $editSearchUrl;
                        $paramsToAppend = [];
                        if (!empty($currentFiltersQuery) && $currentFiltersQuery !== 'price_max=&car_type_capacity=&payment_method=&sort_by=recommended') {
                            parse_str($currentFiltersQuery, $paramsToAppend);
                        }

                        if (!empty($paramsToAppend)) {
                            if (strpos($changeFilterLink, '?') === false) {
                                $changeFilterLink .= '?' . http_build_query($paramsToAppend);
                            } else {
                                $changeFilterLink .= '&' . http_build_query($paramsToAppend);
                            }
                        }
                    ?>
                    <p>Hãy thử thay đổi bộ lọc</a> hoặc <a href="<?= htmlspecialchars($editSearchUrl) ?>">tìm kiếm lại</a>.</p>
                </div>
            <?php else: ?>
                <div class="car-list">
                    <?php foreach ($finalSuitableCars as $car_item): ?>
                        <div class="car-card">
                            <div class="car-image">
                                <img src="<?= htmlspecialchars($car_item['image'] ?? 'placeholder.jpg') ?>" alt="<?= htmlspecialchars($car_item['name'] ?? 'Tên xe') ?>" />
                            </div>
                            <div class="car-details">
                                <h3><?= htmlspecialchars($car_item['name'] ?? 'Không có tên') ?></h3>
                                <div class="car-summary-info">
                                    <p class="capacity-info"><i class="fas fa-users"></i> Tối đa <?= htmlspecialchars($car_item['capacity'] ?? 0) ?> khách</p>
                                    <p class="price-info"><i class="fas fa-money-bill-wave"></i> <?= number_format($car_item['price'] ?? 0, 0, ',', '.') ?> VND</p>
                                </div>
                                <div class="price-action-row">
                                    <button class="btn btn-select-car"
                                        onclick="showCarDetails(
                                            '<?= htmlspecialchars($car_item['name'] ?? 'Không có tên', ENT_QUOTES) ?>',
                                            <?= intval($car_item['capacity'] ?? 0) ?>,
                                            <?= floatval($car_item['price'] ?? 0) ?>,
                                            '<?= htmlspecialchars($car_item['description'] ?? '', ENT_QUOTES) ?>',
                                            '<?= htmlspecialchars(implode(', ', $car_item['features'] ?? []), ENT_QUOTES) ?>',
                                            '<?= htmlspecialchars(implode(', ', array_map(function($m) use ($paymentMethodsMap){ return $paymentMethodsMap[$m] ?? $m; }, $car_item['payment_methods'] ?? [])), ENT_QUOTES) ?>',
                                            '<?= htmlspecialchars($car_item['image'] ?? 'placeholder.jpg', ENT_QUOTES) ?>',
                                            '<?= htmlspecialchars($car_item['id'] ?? 'unknown_car_id', ENT_QUOTES) ?>'
                                        )">
                                        Chọn xe này<i class="fas fa-arrow-right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<div id="car-details-modal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeCarDetails()">×</span>
        <h2>Thông tin chi tiết xe</h2>
        <div class="modal-body">
            <div class="modal-car-image-container">
                       <img id="modal-car-image" src="" alt="Hình ảnh xe">
            </div>
            <div class="modal-car-info">
                <p><strong>Tên xe:</strong> <span id="modal-car-name"></span></p>
                <p><strong>Sức chứa:</strong> <span id="modal-car-capacity"></span> khách</p>
                <p><strong>Giá:</strong> <span id="modal-car-price"></span> VND</p>
                <p><strong>Mô tả:</strong> <span id="modal-car-description"></span></p>
                <p><strong>Tính năng:</strong> <span id="modal-car-features"></span></p>
                <p><strong>Hình thức thanh toán:</strong> <span id="modal-car-payment-methods"></span></p>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-book-now" onclick="promptForPhoneNumber()">Đặt ngay</button>
            <button class="btn btn-close-modal" onclick="closeCarDetails()">Đóng</button>
        </div>
    </div>
</div>

<div id="phone-input-modal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closePhoneInputModal()">×</span>
        <h2>Nhập số điện thoại của bạn</h2>
        <div class="modal-body">
            <p>Vui lòng nhập số điện thoại để chúng tôi liên hệ xác nhận đặt xe:</p>
            <input type="tel" id="phone-number-input" placeholder="Ví dụ: 0912345678" pattern="[0-9]{10,}" title="Vui lòng nhập số điện thoại hợp lệ (ít nhất 10 chữ số)">
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" onclick="validateAndBook()">Xác nhận và Đặt xe</button>
            <button class="btn btn-close-modal" onclick="closePhoneInputModal()">Hủy bỏ</button>
        </div>
    </div>
</div>

<div id="booking-confirmation-modal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeBookingConfirmation()">×</span>
        <h2>Xác nhận đặt xe</h2>
        <div class="modal-body">
            <i class="fas fa-check-circle fa-5x" style="color: #28a745; margin-bottom: 20px;"></i>
            <p style="font-size: 1.2em; text-align: center; color: var(--text-dark);">Bạn đã đặt xe thành công!</p>
            <p style="text-align: center; color: var(--text-light);">Thông tin chi tiết chuyến đi đã được ghi nhận.</p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" onclick="closeBookingConfirmation()">Đóng</button>
        </div>
</div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const range = document.getElementById('price-range');
            const rangeV = document.getElementById('price-range-value');
            if(range && rangeV){
                const updatePriceDisplay = () => {
                    rangeV.innerHTML = `Đến ${parseInt(range.value).toLocaleString('vi-VN')} VND`;
                };
                updatePriceDisplay();
                range.addEventListener('input', updatePriceDisplay);
            }

            const sortBySelect = document.getElementById('sort-by-select');
            const hiddenSortByInput = document.getElementById('hidden_sort_by');
            const filterForm = document.getElementById('filter-form');

            if (sortBySelect && hiddenSortByInput && filterForm) {
                sortBySelect.addEventListener('change', function() {
                    hiddenSortByInput.value = this.value;
                    filterForm.submit();
                });
            }
        });

        let currentSelectedCarId = null;
        let currentSelectedCarRawPrice = null;
        let currentSelectedCarDetails = {};

        function showCarDetails(name, capacity, price, description, features, paymentMethods, image, carId) {
            document.getElementById('modal-car-name').textContent = name;
            document.getElementById('modal-car-capacity').textContent = capacity;
            document.getElementById('modal-car-price').textContent = price.toLocaleString('vi-VN');
            document.getElementById('modal-car-description').textContent = description;
            document.getElementById('modal-car-features').textContent = features;
            document.getElementById('modal-car-payment-methods').textContent = paymentMethods;
            document.getElementById('modal-car-image').src = image;

            currentSelectedCarId = carId;
            currentSelectedCarRawPrice = price;
            currentSelectedCarDetails = {
                id: carId,
                name: name,
                capacity: capacity,
                price: price,
                image: image,
                pickup: "<?= htmlspecialchars($pickup ?? '', ENT_QUOTES) ?>",
                dropoff: "<?= htmlspecialchars($dropoff ?? '', ENT_QUOTES) ?>",
                date: "<?= htmlspecialchars($date ?? '', ENT_QUOTES) ?>",
                time: "<?= htmlspecialchars($time ?? '', ENT_QUOTES) ?>",
                passengers: "<?= htmlspecialchars($passengers ?? 1) ?>"
            };

            document.getElementById('car-details-modal').style.display = 'flex';
        }

        function closeCarDetails() {
            document.getElementById('car-details-modal').style.display = 'none';
        }

        function promptForPhoneNumber() {
            closeCarDetails();
            document.getElementById('phone-input-modal').style.display = 'flex';
            document.getElementById('phone-number-input').value = '';
        }

        function closePhoneInputModal() {
            document.getElementById('phone-input-modal').style.display = 'none';
        }

        function validateAndBook() {
            const phoneNumberInput = document.getElementById('phone-number-input');
            const phoneNumber = phoneNumberInput.value.trim();

            if (!phoneNumber) {
                alert('Vui lòng nhập số điện thoại.');
                return;
            }
            if (!/^[0-9]{10,}$/.test(phoneNumber)) {
                alert('Số điện thoại không hợp lệ. Vui lòng nhập ít nhất 10 chữ số.');
                return;
            }
            currentSelectedCarDetails.phoneNumber = phoneNumber;
            redirectToBooking();
        }

        function redirectToBooking() {
            if (currentSelectedCarId && currentSelectedCarRawPrice !== null) {
                const bookingData = {
                    name: currentSelectedCarDetails.name,
                    pickup: currentSelectedCarDetails.pickup,
                    dropoff: currentSelectedCarDetails.dropoff,
                    passengers: currentSelectedCarDetails.passengers,
                    price: currentSelectedCarDetails.price
                };

                fetch('timxe.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'booking_data=' + encodeURIComponent(JSON.stringify(bookingData))
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        closePhoneInputModal();
                        showBookingConfirmation();
                    } else {
                        alert('Lỗi khi đặt xe: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error during booking:', error);
                    alert('Có lỗi xảy ra trong quá trình đặt xe. Vui lòng thử lại. (Lỗi mạng hoặc phản hồi không hợp lệ)');
                });

            } else {
                alert('Vui lòng chọn xe hoặc có lỗi xảy ra. Thử lại.');
            }
        }

        function showBookingConfirmation() {
            document.getElementById('booking-confirmation-modal').style.display = 'flex';
        }

        function closeBookingConfirmation() {
            document.getElementById('booking-confirmation-modal').style.display = 'none';
        }

        var carDetailsModal = document.getElementById('car-details-modal');
        var phoneInputModal = document.getElementById('phone-input-modal');
        var bookingConfirmModal = document.getElementById('booking-confirmation-modal');

        window.onclick = function(event) {
            if (event.target == carDetailsModal) {
                closeCarDetails();
            } else if (event.target == phoneInputModal) {
                closePhoneInputModal();
            } else if (event.target == bookingConfirmModal) {
                closeBookingConfirmation();
            }
        }
    </script>
</body>
</html>