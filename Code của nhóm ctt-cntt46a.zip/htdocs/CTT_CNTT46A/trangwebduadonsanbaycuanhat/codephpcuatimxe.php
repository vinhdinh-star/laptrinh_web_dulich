<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
session_start();

$servername = "sql210.infinityfree.com";
$username = "if0_39115570";
$password = "nhomcttcntt46a";
$dbname = "if0_39115570_hotrodulich";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    error_log("Kết nối database thất bại: " . $conn->connect_error);
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_data'])) {
        echo json_encode(['success' => false, 'message' => 'Không thể kết nối database.']);
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_data'])) {
    $bookingData = json_decode($_POST['booking_data'], true);

    if ($bookingData) {
        $car_name = $bookingData['name'] ?? '';
        $pickup_location = $bookingData['pickup'] ?? '';
        $dropoff_location = $bookingData['dropoff'] ?? '';
        $passengers_count = $bookingData['passengers'] ?? 0;
        $price = $bookingData['price'] ?? 0;
        $user_fullname = $_SESSION['fullname'] ?? 'Người giấu tên';
        $stmt = $conn->prepare("INSERT INTO lichsudatxe (car_name, pickup_location, dropoff_location, passengers, price, user_fullname, id_khachhang) VALUES (?, ?, ?, ?, ?, ?,?)");
        
        if ($stmt === false) {
            echo json_encode(['success' => false, 'message' => 'Lỗi prepare statement: ' . $conn->error]);
        } else {
            $stmt->bind_param("sssissi", $car_name, $pickup_location, $dropoff_location, $passengers_count, $price, $user_fullname, $_SESSION['id']);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => '']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Lỗi khi lưu đặt xe: ' . $stmt->error]);
            }
            $stmt->close();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Dữ liệu đặt xe không hợp lệ.']);
    }
    $conn->close();
    exit();
}

$pickup = trim($_GET['pickup'] ?? '');
$dropoff = trim($_GET['dropoff'] ?? '');
$date = $_GET['date'] ?? '';
$time = $_GET['time'] ?? '';
$passengers = max(1, intval($_GET['passengers'] ?? 1));


$filter_price_max = intval($_GET['price_max'] ?? 2000000);
$filter_car_type_capacity = $_GET['car_type_capacity'] ?? '';
$filter_payment_method = $_GET['payment_method'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'recommended';

$cars_data = [
    [
        'name' => 'Xe 4 Chỗ Tiêu Chuẩn (Vios/Accent/Kia K3)',
        'capacity' => 4,
        'price' => 250000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-Toyota-Vios-1-1182x800.jpg',
        'description' => 'Các mẫu xe đời mới, tiện nghi, phù hợp đi công tác, du lịch cá nhân hoặc gia đình nhỏ.',
        'features' => ['Điều hòa', 'Xe sạch sẽ', 'Tài xế thân thiện'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 4 Chỗ Giá Rẻ (Morning/i10)',
        'capacity' => 4,
        'price' => 180000,
        'image' => 'https://static.vnfinance.vn/files/huyentrang/2024/07/18/gia-lan-banh-kia-morning-giua-thang-72024-re-lan-at-hyundai-grand-i10-co-hoi-vang-de-tau-xe-anh-2-1418312.jpg',
        'description' => 'Lựa chọn kinh tế cho các chuyến đi ngắn nội thành, tiết kiệm chi phí.',
        'features' => ['Giá tốt', 'Linh hoạt', 'Phù hợp 1-2 khách'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 4 Chỗ Cao Cấp (Mazda 3/Civic/Camry)',
        'capacity' => 4,
        'price' => 450000,
        'image' => 'https://i1-vnexpress.vnecdn.net/2021/09/18/Mazda32020VnE993047211573621051jpg-1631963909.jpg?w=750&h=450&q=100&dpr=1&fit=crop&s=Ksi2dIeIocGk9Pke5aGnRQ',
        'description' => 'Xe đời mới, nội thất sang trọng, trải nghiệm êm ái cho chuyến đi công tác hoặc du lịch cao cấp.',
        'features' => ['Nội thất cao cấp', 'Trải nghiệm êm ái', 'Tài xế chuyên nghiệp'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 4 Chỗ (Đưa Đón Sân Bay - Cá Nhân)',
        'capacity' => 4,
        'price' => 290000,
        'image' => 'https://fpt123.net/uploads/images/dich-vu-thue-xe/anh-xe-tu-lai.jpg',
        'description' => 'Đảm bảo đưa đón đúng giờ tại sân bay Phù Cát, không chờ đợi, giá cố định.',
        'features' => ['Đón tại sân bay', 'Chờ miễn phí', 'Giá trọn gói'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 7 Chỗ (Fortuner/Xpander/Avanza)',
        'capacity' => 7,
        'price' => 350000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-7-cho%CC%82%CC%83-Toyota-Fortuner-1067x800.jpg',
        'description' => 'Lý tưởng cho gia đình hoặc nhóm bạn. Không gian thoải mái cho hành lý và khách.',
        'features' => ['Rộng rãi', 'Thoải mái', 'Phù hợp nhóm'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 7 Chỗ (Đưa Đón Sân Bay - Gia Đình)',
        'capacity' => 7,
        'price' => 390000,
        'image' => 'https://daongocphuquoc.com/wp-content/uploads/2022/08/xe-7-cho.jpg',
        'description' => 'Dịch vụ đưa đón sân bay riêng cho nhóm/gia đình đông hơn, kèm hành lý.',
        'features' => ['Đón tại cửa', 'Hỗ trợ hành lý', 'Không gian rộng'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 7 Chỗ (Trọn Gói 1 Ngày - Du Lịch)',
        'capacity' => 7,
        'price' => 900000,
        'image' => 'https://vodatours.com.vn/uploads/images/7c.jpg',
        'description' => 'Khám phá Quy Nhơn cả ngày với xe 7 chỗ riêng, thoải mái cho cả gia đình.',
        'features' => ['Lái xe kinh nghiệm', 'Hỗ trợ chụp ảnh', 'Nước uống miễn phí'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 16 Chỗ (Ford Transit)',
        'capacity' => 16,
        'price' => 850000,
        'image' => 'https://fordtayninhauto.com/wp-content/uploads/2023/03/ford-transit-16-cho-mau-trang.jpg',
        'description' => 'Xe đời mới, rộng rãi, phục vụ đoàn du lịch nhỏ, đưa đón sự kiện, team building.',
        'features' => ['Ghế ngả', 'Điều hòa mạnh', 'Không gian hành lý rộng'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 16 Chỗ (Đưa Đón Sân Bay - Đoàn)',
        'capacity' => 16,
        'price' => 750000,
        'image' => 'https://dulichviet.com.vn/images/bandidau/images/XE%20DU%20L%E1%BB%8ACH/Xe%2016%20CH%E1%BB%96/thue-xe-mercedes-printer-16-cho-tai-ha-noi-gia-re_du-lich-viet.png',
        'description' => 'Dịch vụ đón/trả sân bay cho các đoàn khách lớn. Đảm bảo tiện nghi và an toàn.',
        'features' => ['Đón tập trung', 'Nhanh chóng', 'Giá ưu đãi'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe 16 Chỗ (Tour Ghềnh Ráng - Eo Gió - Kỳ Co)',
        'capacity' => 16,
        'price' => 1100000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-16-cho%CC%82%CC%83-Hyundai-Solati.jpg',
        'description' => 'Trọn gói tour khám phá các điểm nổi tiếng của Quy Nhơn cho đoàn 16 người.',
        'features' => ['Lịch trình tour riêng', 'Đưa đón tận nơi', 'Bao gồm tài xế'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe Ford Transit Limousine 10 Chỗ (Hạng Sang)',
        'capacity' => 10,
        'price' => 1300000,
        'image' => 'https://www.benthanhford.com.vn/gw-content/images/limousine2019-wiLp0.jpg',
        'description' => 'Trải nghiệm đẳng cấp với ghế massage, TV, Wifi. Phù hợp cho nhóm nhỏ muốn sự riêng tư và thoải mái tối đa.',
        'features' => ['Ghế massage', 'TV giải trí', 'Wifi miễn phí', 'Nước uống'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 29 Chỗ (Đưa Đón Sân Bay - Đoàn Lớn)',
        'capacity' => 29,
        'price' => 1000000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-29-cho%CC%82%CC%83-Samco.jpg',
        'description' => 'Giải pháp đưa đón sân bay tối ưu cho các đoàn khách lớn.',
        'features' => ['Đón tập trung', 'Nhanh chóng', 'Giá ưu đãi'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 29 Chỗ (Tổ chức Team Building/Sự kiện)',
        'capacity' => 29,
        'price' => 1500000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-29-cho%CC%82%CC%83-Hyundai-Universe-Mini-1067x800.jpg',
        'description' => 'Dịch vụ đưa đón cho các hoạt động team building, sự kiện công ty ngoài trời.',
        'features' => ['Đảm bảo an toàn', 'Lái xe nhiệt tình', 'Hỗ trợ hậu cần'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 29 Chỗ (Ký Hợp Đồng, Công Tác Xa)',
        'capacity' => 29,
        'price' => 1350000,
        'image' => 'https://thuexehuydat.com/wp-content/uploads/2018/01/xe29thaco-1.jpg',
        'description' => 'Thuê xe phục vụ nhu cầu công tác, hội nghị, đưa đón đối tác.',
        'features' => ['Chuyên nghiệp', 'Đúng giờ', 'Tiện nghi'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 45 Chỗ (Hyundai Universe/Space)',
        'capacity' => 45,
        'price' => 2000000,
        'image' => 'https://xemiennam.vn/wp-content/uploads/2020/05/Xe-45-cho%CC%82%CC%83-Hyundai-Universe-1400x788.jpg',
        'description' => 'Giải pháp vận chuyển tối ưu cho các đoàn khách lớn nhất, tour dài ngày. Đảm bảo an toàn và thoải mái.',
        'features' => ['Ghế cao cấp', 'Wifi trên xe', 'Hệ thống giải trí', 'Lái xe kinh nghiệm'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 45 Chỗ (Đưa Đón Sân Bay - Đoàn Cực Lớn)',
        'capacity' => 45,
        'price' => 1600000,
        'image' => 'https://hyundaimiennam.com/wp-content/uploads/2023/12/Xe-Khach-Hyundai-Universe-45-cho-4.jpg',
        'description' => 'Đảm bảo đưa đón sân bay cho số lượng khách lớn nhất với xe tiện nghi.',
        'features' => ['Đón tập trung', 'Nhanh chóng', 'Giá ưu đãi'],
        'payment_methods' => ['transfer']
    ],
    [
        'name' => 'Xe 45 Chỗ (Đưa Đón Học Sinh/Sinh Viên)',
        'capacity' => 45,
        'price' => 1700000,
        'image' => 'https://xedoanket.com/wp-content/uploads/2025/03/thue-xe-dua-don-hoc-sinh-dkttransport-6.jpg',
        'description' => 'Phục vụ đưa đón học sinh, sinh viên đi dã ngoại, tham quan, sự kiện.',
        'features' => ['An toàn', 'Chuyên nghiệp', 'Đúng giờ'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe Máy (Xe Số)',
        'capacity' => 2,
        'price' => 100000,
        'image' => 'https://danviet.ex-cdn.com/files/f1/upload/3-2018/images/2018-07-20/honda-alpha-1532071106-width660height495.jpg',
        'description' => 'Lựa chọn phổ biến, tiết kiệm và linh hoạt cho việc di chuyển cá nhân hoặc cặp đôi trong thành phố.',
        'features' => ['Tiết kiệm xăng', 'Linh hoạt', 'Dễ tìm chỗ đậu'],
        'payment_methods' => ['cash', 'transfer']
    ],
    [
        'name' => 'Xe Máy (Tay Ga)',
        'capacity' => 2,
        'price' => 140000,
        'image' => 'https://media.vneconomy.vn/w800/images/upload/2021/04/20/DucTho68.jpg',
        'description' => 'Tiện lợi và dễ lái, phù hợp cho những ai muốn sự thoải mái hơn khi khám phá Quy Nhơn.',
        'features' => ['Tự động', 'Cốp rộng', 'Chạy êm ái'],
        'payment_methods' => ['cash', 'transfer']
    ],
];

function isCarSuitable($car, $passengers) {
    if (stripos($car['name'], 'Xe Máy') !== false) {
        return $passengers <= 2;
    }
    return $car['capacity'] >= $passengers;
}

function filterCars($car, $filter_price_max, $filter_car_type_capacity, $filter_payment_method) {
    if ($filter_price_max !== null && $car['price'] > $filter_price_max) {
        return false;
    }
    if (!empty($filter_car_type_capacity)) {
        $match_capacity = false;
        $car_capacity = $car['capacity'];
        if ($filter_car_type_capacity == '2') {
            if ($car_capacity >= 1 && $car_capacity <= 2) {
                $match_capacity = true;
            }
        }
        elseif ($filter_car_type_capacity == '4' && ($car_capacity >= 4 && $car_capacity < 7)) {
            $match_capacity = true;
        } elseif ($filter_car_type_capacity == '7' && ($car_capacity >= 7 && $car_capacity < 16)) {
            $match_capacity = true;
        } elseif ($filter_car_type_capacity == '16' && ($car_capacity >= 16 && $car_capacity < 28)) {
            $match_capacity = true;
        } elseif ($filter_car_type_capacity == '29' && ($car_capacity >= 29 && $car_capacity < 45)) {
            $match_capacity = true;
        } elseif ($filter_car_type_capacity == '45' && $car_capacity == 45) {
            $match_capacity = true;
        }
        
        if (!$match_capacity) return false;
    }

    if (!empty($filter_payment_method) && !in_array($filter_payment_method, $car['payment_methods'])) {
        return false;
    }
    return true;
}
$validPickup = !empty($pickup);
$validDropoff = !empty($dropoff);
$searchPageUrl = "trangchuduadonsanbay.php";

$initialSearchQuery = http_build_query([
    'pickup' => $pickup,
    'dropoff' => $dropoff,
    'date' => $date,
    'time' => $time,
    'passengers' => $passengers
]);
$editSearchUrl = $searchPageUrl . (strpos($searchPageUrl, '?') === false ? '?' : '&') . $initialSearchQuery;

$currentFiltersQuery = http_build_query([
    'price_max' => $filter_price_max,
    'car_type_capacity' => $filter_car_type_capacity,
    'payment_method' => $filter_payment_method,
    'sort_by' => $sort_by
]);

$passengerSuitableCars = array_filter($cars_data, fn($car) => isCarSuitable($car, $passengers));
$finalSuitableCars = array_filter($passengerSuitableCars, fn($car) => filterCars($car, $filter_price_max, $filter_car_type_capacity, $filter_payment_method));
if ($sort_by === 'price_asc') {
    usort($finalSuitableCars, fn($a, $b) => $a['price'] <=> $b['price']);
} elseif ($sort_by === 'price_desc') {
    usort($finalSuitableCars, fn($a, $b) => $b['price'] <=> $a['price']);
}

foreach ($finalSuitableCars as $key => $car) {
    if (!isset($car['id'])) {
        $finalSuitableCars[$key]['id'] = 'car_' . $key;
    }
}
$is_logged_in_timxe = isset($_SESSION['user_id']) && isset($_SESSION['username']);
$username_timxe = $is_logged_in_timxe ? ($_SESSION['fullname'] ?? $_SESSION['username']) : 'Khách';

$paymentMethodsMap = [
    'cash' => 'Tiền mặt',
    'transfer' => 'Chuyển khoản',
];
if (isset($conn) && $conn->ping() && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $conn->close();
}

?>