<?php
session_start();

$conn = new mysqli("sql210.infinityfree.com", "if0_39115570", "nhomcttcntt46a", "if0_39115570_hotrodulich");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$is_logged_in = isset($_SESSION['username']);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt Xe Đưa Đón Sân Bay Giá Rẻ - Quy Nhơn</title>
    <link rel="stylesheet" href="csssanbay.css" >
</head>
<body>

    <main>
        <section class="hero" style="background-color: #0056b3; background-image: url('https://thichtours.com/wp-content/uploads/2017/01/120932287_931015897423900_8646393099874610409_o-1500x1000.jpg');
        background-size: cover; background-position: center 70%; color: white; padding: 100px 0 120px 0; text-align: center; position: relative;">
            <div class="hero-content container">
                <h1>Xe đưa đón sân bay tiện lợi, giá tốt</h1>
                <p>Đặt xe riêng hoặc xe ghép cho chuyến đi của bạn một cách dễ dàng.</p>
                <div class="search-form-container">
                    <form id="airportTransferForm" method="GET" action="timxe.php">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="origin">Điểm đón</label>
                                <input list="pickup-suggestions" type="text" id="origin" name="pickup" placeholder="Sân bay, Thành phố, Ga tàu" required>
                                <datalist id="pickup-suggestions">
                                    <option value="Sân bay Phù Cát">
                                </datalist>
                            </div>
                            <div class="form-group">
                                <label for="destination">Điểm đến</label>
                                <input list="dropoff-suggestions" type="text" id="destination" name="dropoff" placeholder="Địa chỉ khách sạn, Nhà riêng" required>
                                <datalist id="dropoff-suggestions">
                                    <option value="Trung tâm TP. Quy Nhơn">
                                    <option value="Sân bay Phù Cát">
                                    <option value="Eo Gió">
                                    <option value="Kỳ Co">
                                    <option value="Ghềnh Ráng">
                                    <option value="FLC Quy Nhơn">
                                    <option value="Làng Chài Nhơn Lý">
                                    <option value="Bãi Xép">
                                    <option value="Tháp Đôi">
                                    <option value="Chùa Ông Núi">
                                    <option value="Hòn Khô">
                                    <option value="Làng Phong Quy Hòa">
                                </datalist>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="pickup-date">Ngày đón</label>
                                <input type="date" id="pickup-date" name="date" required min="<?= date('Y-m-d'); ?>"/>
                            </div>
                            <div class="form-group">
                                <label for="pickup-time">Giờ đón</label>
                                <input type="time" id="pickup-time" name="time" required>
                            </div>
                            <div class="form-group">
                                <label for="passengers">Số hành khách</label>
                                <input type="number" id="passengers" name="passengers" value="1" min="1" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-search">Tìm xe</button>
                    </form>
                </div>
            </div>
        </section>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
        const airportTransferForm = document.getElementById('airportTransferForm');
        const isLoggedIn = <?php echo json_encode($is_logged_in); ?>;

        if (airportTransferForm) {
            airportTransferForm.addEventListener('submit', function(event) {
                if (!isLoggedIn) {
                    event.preventDefault();
                    alert('Vui lòng đăng nhập hoặc đăng ký để tìm xe!');
                    setTimeout(function() {
                        window.location.href = '../TrangChu/main page/formDangNhap.php';
                    }, 100);
                }
            });
        }
    });

    </script>
</body>
</html>