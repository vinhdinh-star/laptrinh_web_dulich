<?php
$host = 'sql210.infinityfree.com';
$dbname = 'if0_39115570_hotrodulich';
$username = 'if0_39115570';
$password = 'nhomcttcntt46a';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    echo "Kết nối thất bại: " . $e->getMessage();
}
?>
