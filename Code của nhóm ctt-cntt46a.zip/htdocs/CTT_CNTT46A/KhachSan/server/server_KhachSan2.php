<?php

    include_once "../connect/connect.php";

    $sql = "SELECT * FROM KhachSan";
    $stmt = $pdo->query($sql);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $hotels = [];
    $tienNghiSet = [];
    $loaiHinhSet = [];
    $locations = [];

    $sql_max_price = "SELECT MAX(CAST(gia AS UNSIGNED)) AS max_gia FROM KhachSan;";
    $stmt = $pdo->query($sql_max_price);
    $max_price = 5000000;
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($row && isset($row['max_gia']) && $row['max_gia'] !== null) {
        $max_price = (int)$row['max_gia'];
    }


    foreach ($results as $row) 
    {       

        $locations[] = $row['Locat'];

        $tienNghi = array_map('trim', explode(',', $row['tienNghi']));
        foreach ($tienNghi as $tn) 
        {
            if (!empty($tn)) 
            {
                $tienNghiSet[$tn] = true;
            }
        }

        $loaiHinh = array_map('trim', explode(',', $row['loaiHinh']));
        foreach ($loaiHinh as $lh) 
        {
            if (!empty($lh)) 
            {
                $loaiHinhSet[$lh] = true;
            }
        }

        $hotels[] = [
            'name' => $row['ten'],
            'price' => (int)$row['gia'],
            'stars' => (int)$row['star'],
            'location' => $row['Locat'],
            'loaiHinh' => array_map('trim', explode(',', $row['loaiHinh'])),
            'tienNghi' => array_map('trim', explode(',', $row['tienNghi']))
        ];
    }

    $tienNghiList = array_keys($tienNghiSet);
    sort($tienNghiList);
    $loaiHinhList = array_keys($loaiHinhSet);
    sort($loaiHinhList);
    $locations = array_unique($locations);

?>