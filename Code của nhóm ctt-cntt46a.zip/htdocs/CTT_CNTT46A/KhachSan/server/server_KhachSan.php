<?php 

    include_once "../connect/connect.php";

    $sql = "SELECT DISTINCT Locat FROM KhachSan";
    $stmt = $pdo->query($sql);

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $locations = [];
    $text = [];

    foreach ($results as $row) 
    {
        $locations[] = $row['Locat'];
    }

    foreach ($results as $row) 
    {
        $text[] = $row['Locat'];
    }

    $text[] = "Bạn muốn đến thành phố nào ?";

    $text = array_unique($text);
    $locations = array_unique($locations);
    
?>