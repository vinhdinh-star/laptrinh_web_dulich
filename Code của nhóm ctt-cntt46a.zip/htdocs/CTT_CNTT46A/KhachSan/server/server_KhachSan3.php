<?php

    include_once '../connect/connect.php';

    session_start();

    $ten = $_POST['ht'] ?? '';
        $sdt = $_POST['sdt'] ?? '';
        $noiDat = $_POST['nd'] ?? '';
        $ngayNhanPhong = $_POST['nnp'] ?? '';
        $ngayTraPhong = $_POST['ntp'] ?? '';
        $thanhPho = $_POST['tp'] ?? '';
        $cuThe = $_POST['ct'] ?? '';
        $id = $_SESSION['id'];

        if (empty($ten) || empty($sdt) || empty($noiDat)) {
            echo "Vui lòng điền đầy đủ thông tin.";
            exit;
        }

        $sql = "INSERT INTO UserDatPhong 
            (ten, sdt, noiDat, ngayNhanPhong, ngayTraPhong, thanhPho, cuThe, id_khachHang)
            VALUES 
            (:ten, :sdt, :noiDat, :ngayNhanPhong, :ngayTraPhong, :thanhPho, :cuThe, :id)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':ten' => $ten,
            ':sdt' => $sdt,
            ':noiDat' => $noiDat,
            ':ngayNhanPhong' => $ngayNhanPhong,
            ':ngayTraPhong' => $ngayTraPhong,
            ':thanhPho' => $thanhPho,
            ':cuThe' => $cuThe,
            ':id' => $id
        ]);

    header("Location: ../public/KhachSan_Form.php");
?>