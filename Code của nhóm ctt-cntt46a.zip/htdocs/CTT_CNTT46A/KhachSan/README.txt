url trang chủ: http://localhost/KhachSan/public/KhachSan_Form.php  (đây là phần chính của form)
url trang đặt phòng: http://localhost/KhachSan/public/KhachSan_Form2.php   (trang xuất hiện sau khi nhấn Tìm Khách sạn, không truy cập trực tiếp)

thư mục connect:
+ connect.php            kết nối cơ sở dữ liệu

thư mục css:
+ css_KhachSan_Form1     chứa css cho KhachSan_Form.php
+ css_KhachSan_Form2     chứa css cho KhachSan_Form2.php 

thư mục public:
+ KhachSan_Form.php      Trang chủ
+ KhachSan_Form2.php     Trang đặt phòng (phải vào trang đặt phòng thông qua KhachSan_Form.php)

thư mục server:
+ server_KhachSan.php    phục vụ chính cho KhachSan_Form.php
+ server_KhachSan2.php   phục vụ chính cho KhachSan_Form2.php
+ server_KhachSan3.php   Đưa thông tin đặt phòng từ KhachSan_Form2.php lên CSDL

thư mục sql
+ duLieu.sql             Dữ liệu mẫu
+ KhachSan.sql           Tạo bảng lưu thông tin Khách sạn
+ UserDatPhong.sql       Tạo bảng lưu thông tin người đặt phòng

Lưu ý: chỉ hoạt động tốt khi có kết nối dữ liệu