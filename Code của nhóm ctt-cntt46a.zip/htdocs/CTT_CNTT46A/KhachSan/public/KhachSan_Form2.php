<?php

  include_once '../server/server_KhachSan2.php';
  session_start();

  if (!isset($_SESSION['username'])) {
        header("Location: ../../TrangChu/main page/formDangNhap.php");
        exit(); 
    }

  if ($_SERVER["REQUEST_METHOD"] == "POST")
  { 
    $diadiem = "";
    $diadiem = htmlspecialchars(trim($_POST['diadiem']));
    $nhanPhong = htmlspecialchars(trim($_POST['nhanPhong']));
    $traPhong = htmlspecialchars(trim($_POST['traPhong']));
    $soNguoi = htmlspecialchars(trim($_POST['soNguoi'])); 


  } else 
  {
    header("Location: KhachSan_Form.php");
  }

?>

<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Đặt phòng</title>
    <link rel="stylesheet" href="../css/css_KhachSan_Form2/form-datPhong.css" />
    <link
      rel="stylesheet"
      href="../css/css_KhachSan_Form2/hotel-card_hover.css"
    />
    <link rel="stylesheet" href="../css/css_KhachSan_Form2/sidebar.css" />
    <link rel="stylesheet" href="../css/css_KhachSan_Form2/main_content.css" />
    <link
      rel="stylesheet"
      href="../css/css_KhachSan_Form2/KhachSan_Form2.css"
    />
  </head>
  <body>
    <div class="overlay1 hidden1" id="modalOverlay">
      <div class="modal1" id="modalForm" onclick="event.stopPropagation()">
        <form
          onsubmit="return handleSubmitConfirm()"
          id="form-datPhong"
          method="POST"
          action="../server/server_KhachSan3.php"
        >
          <table>
            <tr>
              <td>Họ tên:</td>
              <td>
                <input
                  type="text"
                  name="ht"
                  id="fullname"
                  readonly
                />
              </td>
            </tr>
            <tr>
              <td>Số điện thoại:</td>
              <td>
                <input
                  type="text"
                  name="sdt"
                  placeholder="Nhập số điện thoại tại đây"
                  required
                />
              </td>
            </tr>
            <tr>
              <td>Tên nơi đặt:</td>
              <td><input type="text" id="nd" name="nd" readonly /></td>
            </tr>
            <tr>
              <td>Ngày nhận phòng:</td>
              <td><input type="text" id="nnp" name="nnp" readonly /></td>
            </tr>
            <tr>
              <td>Ngày trả phòng:</td>
              <td><input type="text" id="ntp" name="ntp" readonly /></td>
            </tr>
            <tr>
              <td>Thành phố:</td>
              <td><input type="text" id="tp" name="tp" readonly /></td>
            </tr>
            <tr>
              <td>Cụ thể:</td>
              <td><input type="text" id="ct" name="ct" readonly /></td>
            </tr>
            <tr>
              <td colspan="2"><input type="submit" value="Đặt phòng" /></td>
            </tr>
          </table>
        </form>
      </div>
    </div>

    <div class="container">
      <div class="sidebar">
        <table>
          <tr>
            <td><label for="priceRange">Giá tối đa (VNĐ):</label></td>
          </tr>
          <tr>
            <td>
              <input
                type="range"
                id="priceRange"
                min="500000"
                max="<?php echo $max_price; ?>"
                step="100000"
                value="<?php echo $max_price; ?>"
              />
            </td>
          </tr>
          <tr>
            <td>
              <div class="price-display" id="priceValue">
                ≤
                <?php echo $max_price; ?>
              </div>
            </td>
          </tr>

          <tr>
            <td><label for="location">Vị trí:</label></td>
          </tr>
          <tr>
            <td>
              <div id="diaDiemCha">
                <input
                  type="text"
                  id="location"
                  placeholder="Tên thành phố"
                  value="<?php echo $diadiem ?>"
                />
                <div id="diaDiemCon"></div>
              </div>
            </td>
          </tr>

          <tr>
            <td>
              <div class="khungChon">
                <table>
                  <tr>
                    <td colspan="2">Số sao</td>
                  </tr>
                  <tr>
                    <td style="height: 5px"></td>
                  </tr>
                  <tr>
                    <td>
                      <input type="checkbox" class="star-filter" value="3" />
                    </td>
                    <td>3 <span class="stars">★ ★ ★</span></td>
                  </tr>
                  <tr>
                    <td>
                      <input type="checkbox" class="star-filter" value="4" />
                    </td>
                    <td>4 <span class="stars">★ ★ ★ ★</span></td>
                  </tr>
                  <tr>
                    <td>
                      <input type="checkbox" class="star-filter" value="5" />
                    </td>
                    <td>5 <span class="stars">★ ★ ★ ★ ★</span></td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>

          <tr>
            <td>
              <div class="khungChon">
                <table>
                  <tr>
                    <td colspan="2">Loại hình lưu trú</td>
                  </tr>
                  <tr>
                    <td style="height: 5px"></td>
                  </tr>
              
                  <?php

                        foreach ($loaiHinhList as $tn) 
                        {
                            echo ' <tr>
                                        <td>
                                          <input
                                            type="checkbox"
                                            class="loaiHinh-filter"
                                            value="' . $tn . '"
                                          />
                                        </td>
                                        <td>' . $tn . '</td>
                                      </tr>';
                        }

                  ?>
         
                  </table>
              </div>
            </td>
          </tr>

          <tr>
            <td>
              <div class="khungChon">
                <table>
                  <tr>
                    <td colspan="2">Tiện nghi</td>
                  </tr>
                  <tr>
                    <td style="height: 5px"></td>
                  </tr>
                  
                  <?php 
                      foreach ($tienNghiList as $tn) 
                      {
                          echo ' <tr>
                                      <td>
                                        <input
                                          type="checkbox"
                                          class="tienNghi-filter"
                                          value="' . $tn . '"
                                        />
                                      </td>
                                      <td>' . $tn . '</td>
                                    </tr>';
                      }
                  
                  
                  ?>
                  
                </table>
              </div>
            </td>
          </tr>
        </table>
      </div>

      <div class="main-content">
        <div class="hotel-list" id="hotelList"></div>
        <div class="pagination" id="pagination"></div>
      </div>
    </div>

    <script>

            const hotels = <?php echo json_encode($hotels, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>

            const elements = {
              loaiHinhCheckboxes: document.querySelectorAll(".loaiHinh-filter"),
              priceRange: document.getElementById("priceRange"),
              priceValue: document.getElementById("priceValue"),
              location: document.getElementById("location"),
              hotelList: document.getElementById("hotelList"),
              pagination: document.getElementById("pagination"),
              starCheckboxes: document.querySelectorAll(".star-filter"),
              tienNghiCheckboxes: document.querySelectorAll(".tienNghi-filter"),
            };

            let filteredHotels = [];
            let currentPage = 1;
            const itemsPerPage = 8;

            function formatPrice(price) {
              return price.toLocaleString("vi-VN") + " VNĐ";
            }

            function displayHotels(list) {
              const start = (currentPage - 1) * itemsPerPage;
              const pagedHotels = list.slice(start, start + itemsPerPage);
              elements.hotelList.innerHTML = "";

              if (pagedHotels.length === 0) {
                elements.hotelList.innerHTML =
                  "<p>Không có khách sạn nào phù hợp.</p>";
                return;
              }

              pagedHotels.forEach((hotel) => {
                const card = document.createElement("div");
                card.className = "hotel-card";
                card.innerHTML = `
                <h3>${hotel.name}</h3>
                <p>Giá: ${formatPrice(hotel.price)}</p>
                <p>Loại hình: ${hotel.loaiHinh.join(", ")}</p>
                <p>Tiện nghi: ${hotel.tienNghi.join(", ")}</p>
                <p class="stars">${"★".repeat(hotel.stars)}</p>
                <p>Vị trí: ${hotel.location}</p>
                <div class="overlay">
                  <button class="action-btn" onclick="showModal('${hotel.name}','${hotel.location}')">Đặt phòng</button>
                </div>
              `;
                elements.hotelList.appendChild(card);
              });

              renderPagination(list.length);
            }

            function renderPagination(totalItems) {
              const totalPages = Math.ceil(totalItems / itemsPerPage);
              elements.pagination.innerHTML = "";

              if (totalPages <= 1) return;

              for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement("button");
                btn.textContent = i;
                btn.classList.toggle("active", i === currentPage);
                btn.onclick = () => {
                  currentPage = i;
                  displayHotels(filteredHotels);
                };
                elements.pagination.appendChild(btn);
              }
            }

            function getSelectedStars() {
              return Array.from(elements.starCheckboxes)
                .filter((cb) => cb.checked)
                .map((cb) => parseInt(cb.value));
            }

            function getSelectedLoaiHinh() {
              return Array.from(elements.loaiHinhCheckboxes)
                .filter((cb) => cb.checked)
                .map((cb) => cb.value);
            }

            function getSelectedTienNghi() {
              return Array.from(elements.tienNghiCheckboxes)
                .filter((cb) => cb.checked)
                .map((cb) => cb.value);
            }

            function filterHotels() {
              const maxPrice = parseInt(elements.priceRange.value);
              const location = elements.location.value.toLowerCase().trim();
              const selectedStars = getSelectedStars();
              const SelectedLoaiHinh = getSelectedLoaiHinh();
              const SelecttienNghi = getSelectedTienNghi();

              elements.priceValue.textContent = `≤ ${formatPrice(maxPrice)}`;

              filteredHotels = hotels.filter((hotel) => {
                const matchPrice = hotel.price <= maxPrice;
                const matchLocation =
                  location == "" || hotel.location.toLowerCase().includes(location);;
                const matchStars =
                  selectedStars.length === 0 || selectedStars.includes(hotel.stars);
                const matchLoaiHinh =
                  SelectedLoaiHinh.length === 0 ||
                  hotel.loaiHinh.some((lh) => SelectedLoaiHinh.includes(lh));
                const matchTienNghi =
                  SelecttienNghi.length === 0 ||
                  hotel.tienNghi.some((lh) => SelecttienNghi.includes(lh));

                return matchPrice && matchLocation && matchStars && matchLoaiHinh && matchTienNghi;
              });

              currentPage = 1;
              displayHotels(filteredHotels);
            }


            ["input", "change"].forEach((event) => {
              elements.priceRange.addEventListener(event, filterHotels);
              elements.location.addEventListener(event, filterHotels);
              elements.starCheckboxes.forEach((cb) =>
                cb.addEventListener(event, filterHotels)
              );
              elements.loaiHinhCheckboxes.forEach((cb) =>
                cb.addEventListener("change", filterHotels)
              );
              elements.tienNghiCheckboxes.forEach((cb) =>
                cb.addEventListener("change", filterHotels)
              );
            });

            filterHotels();

            const diaDiemCon = document.getElementById("diaDiemCon");
          const locationInput = document.getElementById("location");

          const diaDiemList = <?php echo json_encode(array_values($locations), JSON_UNESCAPED_UNICODE); ?>;

          function renderDiaDiemList() {
            diaDiemCon.innerHTML = "";
            const btn = document.createElement("button");
            btn.className = "btnDiaDiem";
            btn.type = "button";
            btn.textContent = "Tất cả";
            btn.onclick = () => chonDiaDiem("");
            diaDiemCon.appendChild(btn);
            diaDiemList.forEach((diaDiem) => {
              const btn = document.createElement("button");
              btn.className = "btnDiaDiem";
              btn.type = "button";
              btn.textContent = diaDiem;
              btn.onclick = () => chonDiaDiem(diaDiem);
              diaDiemCon.appendChild(btn);
            });
          }

          function filterDiaDiem() {
            const diaDiemInput = locationInput.value.toLowerCase().trim();
            const diaDiems = document.querySelectorAll(".btnDiaDiem");
            diaDiems.forEach((diadiem) => {
              const diaDiemName = diadiem.textContent.toLowerCase();
              diadiem.style.display = diaDiemName.includes(diaDiemInput) ? "block" : "none";
            });
          }

          function chonDiaDiem(diaDiem1) {
            if (!locationInput) {
              console.error("Input #location not found");
              return;
            }
            locationInput.value = diaDiem1;
            diaDiemCon.style.height = "0px";
            diaDiemCon.classList.remove("open");
            setTimeout(() => {
              diaDiemCon.style.padding = "0px";
            }, 200);
            a = 1;
            filterHotels();
          }

          let a = 1;

          locationInput.addEventListener("click", function (e) {
            e.stopPropagation();
            if (a === 1) {
              diaDiemCon.style.height = "200px";
              diaDiemCon.classList.add("open");
              a = 0;
            } else {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });

          locationInput.addEventListener("input", filterDiaDiem);

          locationInput.addEventListener("blur", function (e) {
            if (!e.relatedTarget || !diaDiemCon.contains(e.relatedTarget)) {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });
       
          locationInput.addEventListener("keydown", function (e) {
            const diaDiems = Array.from(document.querySelectorAll(".btnDiaDiem:not([style*='display: none'])"));
            if (diaDiems.length === 0) return;

            let index = diaDiems.findIndex((btn) => btn.classList.contains("selected"));

            if (e.key === "ArrowDown") {
              e.preventDefault();
              if (index < diaDiems.length - 1) {
                if (index >= 0) diaDiems[index].classList.remove("selected");
                diaDiems[index + 1].classList.add("selected");
              }
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              if (index > 0) {
                diaDiems[index].classList.remove("selected");
                diaDiems[index - 1].classList.add("selected");
              }
            } else if (e.key === "Enter" && index >= 0) {
              e.preventDefault();
              chonDiaDiem(diaDiems[index].textContent);
            }
          });

          diaDiemCon.addEventListener("click", function (e) {
            e.stopPropagation();
          });

          renderDiaDiemList();
          if (locationInput.value) {
            filterHotels();
          }

          const overlay = document.getElementById("modalOverlay");

          function showModal(a, b) {
          overlay.classList.remove("hidden1");
          document.getElementById("fullname").value = "<?php echo $_SESSION['fullname']; ?>";
          document.getElementById("nd").value = a;
          document.getElementById("nnp").value = <?php echo json_encode($nhanPhong); ?>;
          document.getElementById("ntp").value = <?php echo json_encode($traPhong); ?>;
          document.getElementById("tp").value = b;
          document.getElementById("ct").value = <?php echo json_encode($soNguoi); ?>;
      }


          overlay.addEventListener("click", () => {
            overlay.classList.add("hidden1");
          });

          function handleSubmitConfirm() {
            return confirm("Ok để tiếp tục đặt phòng !");
        }
    </script>
  </body>
</html>
