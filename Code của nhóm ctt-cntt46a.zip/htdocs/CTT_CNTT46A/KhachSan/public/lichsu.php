<?php

require_once '../connect/connect.php';

session_start();


if (isset($_SESSION['id'])) {
    $id = $_SESSION['id'];

    $limit = 5;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;

    $offset = ($page - 1) * $limit;

    $stmt = $pdo->query("SELECT COUNT(*) FROM UserDatPhong where id_khachHang = ".$id."");
    $totalRows = $stmt->fetchColumn();
    $totalPages = ceil($totalRows / $limit);

    $stmt = $pdo->prepare("SELECT * FROM UserDatPhong where id_khachHang = ".$id." LIMIT :limit OFFSET :offset");

    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $khachsans = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if (isset($_GET['a']))
    {
        $stmt = $pdo->query("DELETE FROM UserDatPhong WHERE id = ".$_GET['a']."");
        header("Location: lichsu.php");
        $stmt->execute();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch sử</title>
    <style>
        table
        {
            border-collapse: collapse;
            width: 60%;
            border-radius: 3px;
            overflow: hidden;
            text-align: center; 
            border-radius: 5px;
            opacity: 0.8;
        }

        td
        {
            padding: 10px;
            background-color:rgb(200, 198, 198);
        }

        .nutPhanTrang a
        {
            
        }

    </style>
</head>
<body style="padding-top: 40px; padding-bottom: 40px; background-image: url('https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2');">
    <div style="display: flex; align-items: center; flex-direction: column;">
        <h3 style="font-size: 30px;">Lịch sử đặt phòng Khách sạn</h3>
        <table border="1">
            <tr><td style="background-color:rgb(169, 169, 169); font-size: 20px;">Tên khách sạn</td><td style="background-color:rgb(169, 169, 169); font-size: 20px;">Ngày nhận phòng</td><td style="background-color: rgb(169, 169, 169); font-size: 20px;">Ngày trả phòng</td><td style="background-color: rgb(169, 169, 169); font-size: 20px;">Thành phố</td><td style="background-color: rgb(169, 169, 169); font-size: 20px;">Hủy đặt</td></tr>
            <?php
                foreach ($khachsans as $ks):
                    echo '<tr><td>'.$ks['noiDat'].'</td><td>'.$ks['ngayNhanPhong'].'</td><td>'.$ks['ngayTraPhong'].'</td><td>'.$ks['thanhPho'].'</td><td><a style="text-decoration: none; color: red; font-size: 20px;" href="lichsu.php?a='.$ks['id'].'">Hủy</a></td></tr>';
                endforeach;
            ?>
        </table>
        <?php

        echo '<div class="nutPhanTrang">';
                for ($i = 1; $i <= $totalPages; $i++) {
                    if ($i == $page) {
                        echo '<a style="background-color: #8fff9b;>' . $i . '</a> ';
                    } else {
                        echo '<a href="?page=' . $i . '">' . $i . '</a> ';
                    }
                }
        echo '</div>';

        ?>
    </div>
</body>
</html>