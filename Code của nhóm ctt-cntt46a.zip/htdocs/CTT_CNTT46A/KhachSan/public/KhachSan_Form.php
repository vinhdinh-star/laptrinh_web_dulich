<?php
    include_once '../server/server_KhachSan.php';

?>

<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Đặt Phòng Khách Sạn</title>
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="../css/css_KhachSan_Form1/form-timKhachSan.css"
    />
    <style>
      body {
        padding: 0;
        margin: 0;
        font-family: Arial, sans-serif;
        background-image: url("https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2");
      }
    </style>
  </head>
  <body>
    <div id="container">
      <form id="input-hotel" method="POST" action="KhachSan_Form2.php">
        <table>
          <tr>
            <td colspan="3">Thành phố, địa điểm:</td>
            <td style="text-align: right;"><a class="lichsu" href="lichsu.php">Lịch sử đặt phòng</a></td>
          </tr>
          <tr>
            <td colspan="4">
              <div id="diaDiemCha">
                <i class="bx bx-map"></i>
                <input
                  type="text"
                  id="diaDiem"
                  onkeyup="filterDiaDiem()"
                  name="diadiem"
                  required
                />
                <div id="diaDiemCon"></div>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="2">Nhận phòng:</td>
            <td colspan="2">Trả phòng:</td>
          </tr>
          <tr>
            <td colspan="2">
              <div class="lich">
                <i class="bx bx-calendar"></i>
                <input
                  style="padding-left: 40px; max-width: 380px"
                  type="text"
                  id="nhanPhong"
                  name="nhanPhong"
                  required
                />
                <div id="lichNhanPhong">
                  <div class="calendar-header">
                    <button type="button" onclick="prevMonth()">&lt;</button>
                    <h3 id="monthYear"></h3>
                    <button type="button" onclick="nextMonth()">&gt;</button>
                  </div>
                  <div class="day-names">
                    <div>CN</div>
                    <div>T2</div>
                    <div>T3</div>
                    <div>T4</div>
                    <div>T5</div>
                    <div>T6</div>
                    <div>T7</div>
                  </div>
                  <div class="days" id="calendarDays"></div>
                </div>
              </div>
            </td>
            <td colspan="2">
              <div class="lich1">
                <i class="bx bx-calendar"></i>
                <input
                  style="padding-left: 40px; max-width: 380px"
                  type="text"
                  id="traPhong"
                  name="traPhong"
                  required
                />
                <div id="lichTraPhong">
                  <div class="calendar-header">
                    <button type="button" onclick="prevMonth1()">&lt;</button>
                    <h3 id="monthYear1"></h3>
                    <button type="button" onclick="nextMonth1()">&gt;</button>
                  </div>
                  <div class="day-names">
                    <div>CN</div>
                    <div>T2</div>
                    <div>T3</div>
                    <div>T4</div>
                    <div>T5</div>
                    <div>T6</div>
                    <div>T7</div>
                  </div>
                  <div class="days" id="calendarDays1"></div>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="4">Khách và Phòng:</td>
          </tr>
          <tr>
            <td colspan="2">
              <div id="KhachvaPhong">
                <i class="bx bx-group"></i>
                <input
                  style="padding-left: 40px; max-width: 300px"
                  type="text"
                  id="khachPhong"
                  value="1 người lớn, 0 trẻ em, 1 phòng"
                  name="soNguoi"
                  readonly
                />
                <div id="KP">
                  <table>
                    <tr>
                      <td>Người lớn (trên 16)</td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button type="button" class="btnTG" onclick="GiamLon()">
                          -
                        </button>
                      </td>
                      <td
                        style="width: 20px; height: 20px; text-align: center"
                        id="Lon"
                      >
                        1
                      </td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button type="button" class="btnTG" onclick="TangLon()">
                          +
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Trẻ em (dưới 16)</td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button type="button" class="btnTG" onclick="GiamNho()">
                          -
                        </button>
                      </td>
                      <td
                        style="width: 20px; height: 20px; text-align: center"
                        id="Nho"
                      >
                        0
                      </td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button type="button" class="btnTG" onclick="TangNho()">
                          +
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Phòng</td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button
                          type="button"
                          class="btnTG"
                          onclick="GiamPhong()"
                        >
                          -
                        </button>
                      </td>
                      <td
                        style="width: 20px; height: 20px; text-align: center"
                        id="Phong"
                      >
                        1
                      </td>
                      <td style="width: 20px; height: 20px; text-align: center">
                        <button
                          type="button"
                          class="btnTG"
                          onclick="TangPhong()"
                        >
                          +
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td colspan="4">Lưu ý:</td>
                    </tr>
                    <tr>
                      <td colspan="4">Số người lớn tối đa 30 người</td>
                    </tr>
                    <tr>
                      <td colspan="4">Số trẻ em tối đa 6 người</td>
                    </tr>
                    <tr>
                      <td colspan="4">Số phòng tối đa 8 phòng</td>
                    </tr>
                    <tr>
                      <td colspan="4">
                        Số phòng không được nhiều hơn số người lớn
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </td>
            <td colspan="2">
              <input type="submit" value="" id="timKiem" />
            </td>
          </tr>
        </table>
      </form>
    </div>
    <script>
          const inputHotel = document.getElementById("input-hotel");
          const timKiem = document.getElementById("timKiem");
          const diaDiem = document.getElementById("diaDiem");
          const diaDiemCon = document.getElementById("diaDiemCon");

          const diaDiemList = <?php echo isset($locations) && !empty($locations) ? json_encode(array_values($locations), JSON_UNESCAPED_UNICODE) : '["kết nối CSDL thất bại !"]'; ?>;

          function renderDiaDiemList() {
            diaDiemCon.innerHTML = "";
            diaDiemList.forEach((diaDiem) => {
              const btn = document.createElement("button");
              btn.className = "btnDiaDiem";
              btn.type = "button";
              btn.textContent = diaDiem;
              btn.onclick = () => chonDiaDiem(diaDiem);
              diaDiemCon.appendChild(btn);
            });
          }

          function filterDiaDiem() {
            const diaDiemInput = diaDiem.value.toLowerCase();
            const diaDiems = document.querySelectorAll(".btnDiaDiem");
            diaDiems.forEach((diadiem) => {
              const diaDiemName = diadiem.textContent.toLowerCase();
              diadiem.style.display = diaDiemName.includes(diaDiemInput) ? "block" : "none";
            });
          }

          function chonDiaDiem(diaDiem1) {
            if (!diaDiem) {
              console.error("Input #diaDiem not found");
              return;
            }
            diaDiem.value = diaDiem1;
            diaDiemCon.style.height = "0px";
            diaDiemCon.classList.remove("open");
            setTimeout(() => {
              diaDiemCon.style.padding = "0px";
            }, 200);
            a = 1;
          }

          let a = 1;

          diaDiem.addEventListener("click", function (e) {
            e.stopPropagation();
            if (a === 1) {
              diaDiemCon.style.height = "200px";
              diaDiemCon.classList.add("open");
              a = 0;
            } else {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });

          diaDiem.addEventListener("blur", function (e) {
            if (!e.relatedTarget || !diaDiemCon.contains(e.relatedTarget)) {
              diaDiemCon.style.height = "0px";
              diaDiemCon.classList.remove("open");
              setTimeout(() => {
                diaDiemCon.style.padding = "0px";
              }, 200);
              a = 1;
            }
          });

          diaDiem.addEventListener("keydown", function (e) {
            const diaDiems = Array.from(document.querySelectorAll(".btnDiaDiem:not([style*='display: none'])"));
            if (diaDiems.length === 0) return;

            let index = diaDiems.findIndex((btn) => btn.classList.contains("selected"));

            if (e.key === "ArrowDown") {
              e.preventDefault();
              if (index < diaDiems.length - 1) {
                if (index >= 0) diaDiems[index].classList.remove("selected");
                diaDiems[index + 1].classList.add("selected");
              }
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              if (index > 0) {
                diaDiems[index].classList.remove("selected");
                diaDiems[index - 1].classList.add("selected");
              }
            } else if (e.key === "Enter" && index >= 0) {
              e.preventDefault();
              chonDiaDiem(diaDiems[index].textContent);
            }
          });

          diaDiemCon.addEventListener("click", function (e) {
            e.stopPropagation();
          });

          renderDiaDiemList();

          function checkWidth() {
            timKiem.value = inputHotel.offsetWidth > 500 ? "Tìm khách sạn" : "Tìm";
          }

          checkWidth();
          window.addEventListener("resize", checkWidth);

          let currentDate = new Date();
          let currentDate1 = new Date();
          let ngayDat = new Date(currentDate);
          let ngayTra = new Date(currentDate1);
          let isu = 1;

          function renderCalendar(date) {
            const calendarDays = document.getElementById("calendarDays");
            const monthYear = document.getElementById("monthYear");
            const month = date.getMonth();
            const year = date.getFullYear();

            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();

            monthYear.textContent = `${date.toLocaleString("vi", { month: "long" })} ${year}`;
            calendarDays.innerHTML = "";

            for (let i = 0; i < firstDay; i++) {
              calendarDays.innerHTML += `<div class="disabled"></div>`;
            }

            const today = new Date(new Date().setHours(0, 0, 0, 0));
            for (let day = 1; day <= daysInMonth; day++) {
              const currentDay = new Date(year, month, day);
              const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
              const isBeforeToday = currentDay < today;
              const isAfterNgayTra = isu === 0 && currentDay > ngayTra;

              calendarDays.innerHTML += `
                <div class="${isToday ? "today" : ""} ${isBeforeToday || isAfterNgayTra ? "disabled" : ""} ${
                  ngayDat.getDate() === day && ngayDat.getMonth() === month && ngayDat.getFullYear() === year ? "dateClick" : ""
                }" onclick="chonNgay(${day}, ${month + 1}, ${year})">${day}</div>`;
            }
          }

          function renderCalendar1(date) {
            const calendarDays1 = document.getElementById("calendarDays1");
            const monthYear1 = document.getElementById("monthYear1");
            const month = date.getMonth();
            const year = date.getFullYear();

            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();

            monthYear1.textContent = `${date.toLocaleString("vi", { month: "long" })} ${year}`;
            calendarDays1.innerHTML = "";

            for (let i = 0; i < firstDay; i++) {
              calendarDays1.innerHTML += `<div class="disabled"></div>`;
            }

            for (let day = 1; day <= daysInMonth; day++) {
              const currentDay = new Date(year, month, day);
              const isToday = day === new Date().getDate() && month === new Date().getMonth() && year === new Date().getFullYear();
              const isBeforeNgayDat = currentDay < ngayDat;

              calendarDays1.innerHTML += `
                <div class="${isToday ? "today" : ""} ${isBeforeNgayDat ? "disabled" : ""} ${
                  ngayTra.getDate() === day && ngayTra.getMonth() === month && ngayTra.getFullYear() === year ? "dateClick" : ""
                }" onclick="chonNgay1(${day}, ${month + 1}, ${year})">${day}</div>`;
            }
          }

          function prevMonth() {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar(currentDate);
          }

          function nextMonth() {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar(currentDate);
          }

          function prevMonth1() {
            currentDate1.setMonth(currentDate1.getMonth() - 1);
            renderCalendar1(currentDate1);
          }

          function nextMonth1() {
            currentDate1.setMonth(currentDate1.getMonth() + 1);
            renderCalendar1(currentDate1);
          }

          function chonNgay(day, month, year) {
            const nhanPhong = document.getElementById("nhanPhong");
            nhanPhong.value = `${day}/${month}/${year}`;
            ngayDat = new Date(year, month - 1, day);
            renderCalendar(currentDate);
            renderCalendar1(currentDate1);
            isLichNhanOpen = false;
            updateLichDisplay();
          }

          function chonNgay1(day, month, year) {
            const traPhong = document.getElementById("traPhong");
            traPhong.value = `${day}/${month}/${year}`;
            ngayTra = new Date(year, month - 1, day);
            isu = 0;
            renderCalendar(currentDate);
            renderCalendar1(currentDate1);
            isLichTraOpen = false;
            updateLichDisplay();
          }

          renderCalendar(currentDate);
          renderCalendar1(currentDate1);

          const nhanPhong = document.getElementById("nhanPhong");
          const traPhong = document.getElementById("traPhong");
          const lichNhanPhong = document.getElementById("lichNhanPhong");
          const lichTraPhong = document.getElementById("lichTraPhong");

          let isLichNhanOpen = false;
          let isLichTraOpen = false;

          nhanPhong.addEventListener("click", function (e) {
            e.stopPropagation();
            isLichNhanOpen = !isLichNhanOpen;
            isLichTraOpen = false;
            updateLichDisplay();
          });

          traPhong.addEventListener("click", function (e) {
            e.stopPropagation();
            isLichTraOpen = !isLichTraOpen;
            isLichNhanOpen = false;
            updateLichDisplay();
          });

          document.addEventListener("click", function (e) {
            if (!lichNhanPhong.contains(e.target) && !nhanPhong.contains(e.target)) {
              isLichNhanOpen = false;
            }
            if (!lichTraPhong.contains(e.target) && !traPhong.contains(e.target)) {
              isLichTraOpen = false;
            }
            updateLichDisplay();
          });

          function updateLichDisplay() {

        lichNhanPhong.style.height = isLichNhanOpen ? "270px" : "0px";
        if (isLichNhanOpen) {
          lichNhanPhong.style.padding = "10px";
        } else {
          setTimeout(() => {
            lichNhanPhong.style.padding = "0px";
          }, 300);
        }


        lichTraPhong.style.height = isLichTraOpen ? "270px" : "0px";
        if (isLichTraOpen) {
          lichTraPhong.style.padding = "10px";
        } else {
          setTimeout(() => {
            lichTraPhong.style.padding = "0px";
          }, 300);
        }
      }

          const khachPhong = document.getElementById("khachPhong");
          const KP = document.getElementById("KP");
          let isKhachPhongOpen = false;

          khachPhong.addEventListener("click", function (e) {
            e.stopPropagation();
            isKhachPhongOpen = !isKhachPhongOpen;
            KP.style.height = isKhachPhongOpen ? "490px" : "0px";
          });

          document.addEventListener("click", function (e) {
            if (!KP.contains(e.target) && !khachPhong.contains(e.target)) {
              isKhachPhongOpen = false;
              KP.style.height = "0px";
            }
          });

          let nguoiLon = 1;
          let treEm = 0;
          let soPhong = 1;

          function updateKhachPhong() {
            khachPhong.value = `${nguoiLon} người lớn, ${treEm} trẻ em, ${soPhong} phòng`;
          }

          function TangLon() {
            if (nguoiLon < 30) nguoiLon++;
            document.getElementById("Lon").textContent = nguoiLon;
            updateKhachPhong();
          }

          function GiamLon() {
            if (nguoiLon > 1 && nguoiLon > soPhong) nguoiLon--;
            document.getElementById("Lon").textContent = nguoiLon;
            updateKhachPhong();
          }

          function TangNho() {
            if (treEm < 6) treEm++;
            document.getElementById("Nho").textContent = treEm;
            updateKhachPhong();
          }

          function GiamNho() {
            if (treEm > 0) treEm--;
            document.getElementById("Nho").textContent = treEm;
            updateKhachPhong();
          }

          function TangPhong() {
            if (soPhong < nguoiLon && soPhong < 8) soPhong++;
            document.getElementById("Phong").textContent = soPhong;
            updateKhachPhong();
          }

          function GiamPhong() {
            if (soPhong > 1) soPhong--;
            document.getElementById("Phong").textContent = soPhong;
            updateKhachPhong();
          }

          const texts = <?php echo json_encode(array_values($text), JSON_UNESCAPED_UNICODE); ?>;

          let textIndex = 0;
          let charIndex = 0;
          let isDeleting = false;

          function loopPlaceholders() {
            if (diaDiem.value.length > 0) {
              setTimeout(loopPlaceholders, 100);
              return;
            }
            const currentText = texts[textIndex];
            const currentSubstring = currentText.substring(0, charIndex);
            diaDiem.setAttribute("placeholder", currentSubstring);

            if (!isDeleting) {
              charIndex++;
              if (charIndex > currentText.length) {
                isDeleting = true;
                setTimeout(loopPlaceholders, 1500);
                return;
              }
            } else {
              charIndex--;
              if (charIndex < 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
              }
            }
            setTimeout(loopPlaceholders, isDeleting ? 50 : 100);
          }

          loopPlaceholders();
    </script>
  </body>
</html>
