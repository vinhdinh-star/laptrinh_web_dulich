CREATE TABLE nguoidung (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(100),
    dob DATE,
    gioitinh VARCHAR(10) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
