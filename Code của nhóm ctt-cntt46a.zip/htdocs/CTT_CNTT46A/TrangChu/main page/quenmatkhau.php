<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Quên Mật Khẩu</title>
  <link rel="stylesheet" href="../css/thietkedangnhap.css">
</head>
<body>
  <div class="container">
    <h2>Quên Mật Khẩu</h2>
    <form action="../server/xuly_quenmatkhau.php" method="post">
      <input type="email" name="email" placeholder="Nhập email của bạn" required>
      <button type="submit">Gửi liên kết đặt lại mật khẩu</button>
    </form>
    <p style="margin-top: 15px;">
      <a href="formDangNhap.php" style="color: #2e91b3;">Quay lại đăng nhập</a>
    </p>
  </div>
</body>
</html>
