<?php
  session_start();

  if (!isset($_SESSION['username'])) {
        header("Location: ../TrangChu/main page/formDangNhap.php");
        exit(); 
    }

?>


<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Đặt xe</title>
  <style>
    body {
      margin: 0;
      background: #e9f6f8;
    }

    .hero {
      background: linear-gradient(to bottom, LightIceBlue, White);
      padding: 40px 20px;
      text-align: center;
    }

   
    .hero h1 {
      font-size: 28px;
      color: #222;
      margin-bottom: 20px;
    }

    .tabs {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }

    .tab {
      padding: 10px 20px;
      background: #e0f3f7;
      border-radius: 10px 10px 0 0;
      cursor: pointer;
      font-weight: bold;
      color: #333;
    }

    .tab.active {
      background: #ffffff;
      border-bottom: 3px solid #00bcd4;
    }

    .form-box {
      background: #fff;
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      text-align: left;
    }

    .form-group {
      margin-bottom: 15px;
    }

    label {
      display: block;
      font-weight: 500;
      margin-bottom: 5px;
      color: #555;
    }

    input[type="text"], input[type="datetime-local"], select {
      width: 100%;
      padding: 12px;
      font-size: 15px;
      border: 1px solid #ccc;
      border-radius: 10px;
      box-sizing: border-box;
    }

    .form-box button {
      width: 100%;
      background: #ffaa00;
      color: white;
      border: none;
      padding: 14px;
      font-size: 16px;
      font-weight: bold;
      border-radius: 10px;
      cursor: pointer;
      margin-top: 10px;
    }

    .form-box button:hover {
      background: #e69500;
    }

    .form-section {
      display: none;
    }

    .form-section.active {
      display: block;
    }
	.dichvu-item { width: 480px; border: 9px solid white;  border-radius: 10px; padding: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

	.nut-dong {
    position: absolute;
    top: 10px;
    right: 10px;
    background-color: crimson;
    color: white;
    border: none;
    padding: 6px 12px;
    font-size: 18px;
    cursor: pointer;
    border-radius: 50%;
}

.thongtin {
		background-color: white;
		
		border-radius: 10px;
		margin: 30px auto;
		max-width: 1900px;
		 position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow-y: auto;
            padding: 30px;
            display: none;
            z-index: 999;
		}
        abs {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }

    .tab {
      padding: 10px 20px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 10px 10px 0 0;
      cursor: pointer;
      font-weight: bold;
      color: #333;
    }

    .tab.active {
      background: #ffffff;
      border-bottom: 3px solid #00bcd4;
    }

    .form-box {
      background: #fff;
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      text-align: left;
    }

  </style>
</head>
<body>
<div >
		<input type="button" onclick="window.location.href='../../index.php'" value="trang chủ">
</div>

<div class="hero">
<img class="bg-image" src="https://tse3.mm.bing.net/th?id=OIP.TFItkc1SfUi771RY8UPqFAHaE8&pid=Api&P=0&h=220" alt="Ảnh xe">
  <div class="hero-content">
  <h1>Đồng Hành Mọi Chuyến Đi Của Bạn</h1>

  <div class="tabs">
    <div class="tab active" onclick="showTab(0)">🚗 Xe tự lái</div>
    <div class="tab" onclick="showTab(1)">🚘 Xe có tài xế</div>
  </div>

  <!-- Form: Tự lái xe -->
  <form class="form-section active form-box" action="luudiachi.php" method="POST">
 <div class="form-group">
    <label for="diadiem">Địa chỉ của khách hàng</label>
    <input type="text" id="diadiem" name="diadiem" list="ds_diadiem" required>
	<datalist id="ds_diadiem">
  <!-- sẽ được thêm tự động bằng JavaScript -->
</datalist>
  </div>
  <button type="submit" onclick="handleSubmit()">TÌM XE</button>
</form>

  <!-- Form: Xe có tài xế -->
  <form class="form-section form-box" method="POST" action="luudulieu_ctx.php">
    <div class="form-group">
      <label>Điểm đón</label>
      <input type="text" name="diemdon" placeholder="Chọn địa điểm đón">
    </div>
    <div class="form-group">
      <label for="diemden">Điểm đến</label>
      <input type="text" name="diemden" list ="ds_diemden" placeholder="Chọn dịa điểm đến">
	  <datalist id="ds_diemden">
  <!-- sẽ được thêm tự động bằng JavaScript -->
</datalist>
    </div>
    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue" min="<?= date('Y-m-d') ?>T00:00" >
      <input type="datetime-local"  name="tgtra" style="margin-top: 10px;" min="<?= date('Y-m-d') ?>T00:00">
    </div>
   <button type="submit">TÌM XE</button>
   </form>
 
<div>
<form action="lichsu_thuexe.php" method="POST">
		<button style="padding: 8px; background-color:white; border:1px solid #ccc;
                   border-radius: 10px; font-weight:bold;" type="submit">LỊCH SỬ THUÊ XE</button>
</div> 
  </div>
</div>
</div>
</form>


<script>
  function showTab(index) {
    const tabs = document.querySelectorAll('.tab');
    const forms = document.querySelectorAll('.form-section');

    tabs.forEach((tab, i) => {
      tab.classList.toggle('active', i === index);
    });

    forms.forEach((form, i) => {
      form.classList.toggle('active', i === index);
    });
  }
  
  function showThongTin(id) {
  var el = document.getElementById(id);
  if (el) {
    el.style.display = 'block';
  }
    // Cuộn xuống nếu muốn
    thongTinDiv.scrollIntoView({ behavior: "smooth" });
}

function showTab(index) {
    const tabs = document.querySelectorAll('.tab');
    const forms = document.querySelectorAll('.form-section');

    tabs.forEach((tab, i) => {
      tab.classList.toggle('active', i === index);
    });

    forms.forEach((form, i) => {
      form.classList.toggle('active', i === index);
    });
  }

  function handleSubmit() {
    const activeTab = document.querySelector('.tab.active');
    const tabText = activeTab.textContent.trim();

    if (tabText.includes("Xe tự lái")) {
        const diadiem = document.getElementById('diadiem').value;

        fetch('luudiachi.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'diadiem=' + encodeURIComponent(diadiem)
        })
        .then(res => res.text())
        .then(data => {
            console.log("Đã lưu:", data);
            // ✅ Sau khi đã gửi xong, mới chuyển trang
            window.location.href = "tulaixe.php";
        })
        .catch(err => {
            alert("Gửi địa chỉ thất bại: " + err);
        });

    } else if (tabText.includes("có tài xế")) {
			const diemden = document.getElementById('diemden').value;
			const diemdon = document.getElementById('diemdon').value;
			const tgthue = document.getElementById('tgthue').value;
			const tgtra = document.getElementById('tgtra').value;

        fetch('luudulieu_ctx.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'diemden=' + encodeURIComponent(diemden) +
					'diemdon=' + encodeURIComponent(diemdon)+
					'tgthue=' + encodeURIComponent(tgthue)+
					'tgtra=' + encodeURIComponent(tgtra)
        })
        .then(res => res.text())
        .then(data => {
            console.log("Đã lưu:", data);
            // ✅ Sau khi đã gửi xong, mới chuyển trang
            window.location.href = "timxe.php";
        })
        .catch(err => {
            alert("Gửi thất bại: " + err);
        });
		
        
    } else {
        alert("Không xác định được loại dịch vụ");
    }
}


  function showTab(index) {
    const tabs = document.querySelectorAll(".tab");
    const sections = document.querySelectorAll(".form-section");

    tabs.forEach((tab, i) => {
      tab.classList.toggle("active", i === index);
    });

    sections.forEach((section, i) => {
      section.classList.toggle("active", i === index);
    });
  }

  function showThongTin(id) {
    document.getElementById(id).style.display = 'block';
  }
  
   const diaDiemHopLe = ["trung tâm Tp Quy Nhơn", "Làng Chài Nhơn Lý", "Nhơn Hải", "Cát Tiến", "Chùa Ông Núi", "Tháp Đôi", "Bãi xếp", "Sân bay Phù Cát"];
    const dataList = document.getElementById("ds_diadiem");
    const input = document.getElementById("diadiem");

    // Tạo các lựa chọn cho datalist
    diaDiemHopLe.forEach(function (diadiem) {
        const option = document.createElement("option");
        option.value = diadiem;
        dataList.appendChild(option);
    });

    // Kiểm tra hợp lệ khi form được gửi
    document.querySelector("form").addEventListener("submit", function (e) {
        if (!diaDiemHopLe.includes(input.value)) {
            alert("Chỉ được chọn địa điểm hợp lệ!");
            e.preventDefault(); // Chặn gửi form
        }
    });
	
	
	const diemdenHopLe = ["trung tâm Tp Quy Nhơn", "Làng Chài Nhơn Lý", "Nhơn Hải", "Cát Tiến", "Chùa Ông Núi", "Tháp Đôi", "Bãi xếp", "Sân bay Phù Cát"];
    const dataListt = document.getElementById("ds_diemden");
    const inputt = document.getElementById("diemden");

    // Tạo các lựa chọn cho datalist
    diemdenHopLe.forEach(function (diemden) {
        const option = document.createElement("option");
        option.value = diemden;
        dataListt.appendChild(option);
    });

    // Kiểm tra hợp lệ khi form được gửi
    document.querySelector("form").addEventListener("submit", function (e) {
        if (!diemdenHopLe.includes(inputt.value)) {
            alert("Chỉ được chọn địa điểm hợp lệ!");
            e.preventDefault(); // Chặn gửi form
        }
    });

</script>

</body>
</html>