<?php
session_start();

$_SESSION['diadiem'] = $_POST['diadiem'];

header("Location: tulaixe.php");
exit;
?>
