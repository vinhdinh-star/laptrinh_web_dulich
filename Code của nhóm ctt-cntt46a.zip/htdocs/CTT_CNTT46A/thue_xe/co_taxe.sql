-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2025 at 07:00 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotrodulich`
--

-- --------------------------------------------------------

--
-- Table structure for table `co_taxe`
--

CREATE TABLE `co_taxe` (
  `user_id` varchar(50) NOT NULL,
  `diemdon` text DEFAULT NULL,
  `diemden` text DEFAULT NULL,
  `tgthue` datetime DEFAULT NULL,
  `tgtra` datetime DEFAULT NULL,
  `ten_taixe` text NOT NULL,
  `sodt` varchar(10) NOT NULL,
  `kinhnghiem` text NOT NULL,
  `socho_ngoi` text NOT NULL,
  `gias` int(11) NOT NULL,
  `bien_soxe` varchar(50) NOT NULL,
  `id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `co_taxe`
--

INSERT INTO `co_taxe` (`user_id`, `diemdon`, `diemden`, `tgthue`, `tgtra`, `ten_taixe`, `sodt`, `kinhnghiem`, `socho_ngoi`, `gias`, `bien_soxe`, `id`) VALUES
('', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Đặng Tiến Hoàng', '0356565678', '5 năm', '4 chỗ', 150000, '77A-580.11', 0),
('', NULL, NULL, NULL, NULL, 'Vương Bình', '0863486723', '11 năm', '', 150000, '77H-129.76', 0),
('', NULL, NULL, NULL, NULL, 'Chu Dật Tài', '0934867234', '8 năm', '7 chỗ', 150000, '77L-123.11', 0),
('', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Trần Minh Hiếu', '0356565670', '6 năm', '4 chỗ', 150000, '77C-970.72', 0),
('', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Bình Vàng', '0356545632', '6 năm', '4 chỗ', 150000, '77D-100.00', 0),
('', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Trịnh Trần Phương Tuấn', '0432423432', '3 năm', '16 chỗ', 150000, '77A-555.51', 0),
('', 'dfgdf', 'dsfasf', '2025-05-29 08:52:00', '2025-05-31 08:52:00', 'Bình Vàng', '0356545632', '6 năm', '4 chỗ', 150000, '77D-100.00', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
