<?php
include_once 'connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../TrangChu/main page/formDangNhap.php");
    exit;
}

$user_id = $_SESSION['username'];

// ✅ Xử lý yêu cầu hủy chuyến
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['huy_id'], $_POST['loai'])) {
    $huy_id = $_POST['huy_id'];
    $loai = $_POST['loai'];

    $allowedTables = ['co_taxe', 'xe_tulai'];
    if (!in_array($loai, $allowedTables)) {
        echo json_encode(['success' => false, 'message' => '❌ Bảng không hợp lệ!']);
        exit;
    }

    try {
        // ✅ Chỉ xóa đúng 1 chuyến của user hiện tại
        $stmt = $pdo->prepare("DELETE FROM $loai WHERE id = ? AND user_id = ? LIMIT 1");
        $stmt->execute([$huy_id, $user_id]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => '✅ Đã hủy chuyến thành công!']);
        } else {
            echo json_encode(['success' => false, 'message' => '⚠️ Không tìm thấy chuyến để hủy!']);
        }
        exit;
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => '❌ Lỗi khi hủy: ' . $e->getMessage()]);
        exit;
    }
}

// ✅ Lấy dữ liệu lịch sử thuê xe
$stmt1 = $pdo->prepare("SELECT * FROM co_taxe WHERE user_id = ? ORDER BY tgthue DESC");
$stmt1->execute([$user_id]);
$ds_taxe = $stmt1->fetchAll();

$stmt2 = $pdo->prepare("SELECT * FROM xe_tulai WHERE user_id = ? ORDER BY tgthue DESC");
$stmt2->execute([$user_id]);
$ds_tulai = $stmt2->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lịch sử thuê xe</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 40px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .cancel-btn {
            color: white;
            background-color: red;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        .cancel-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
<div>
    <input type="button" onclick="window.location.href='thuexe.php'" value="Quay lại trang thuê xe">
</div>

<h2>🚗 Lịch sử thuê xe có tài xế</h2>
<table>
    <tr>
        <th>Điểm đón</th><th>Điểm đến</th><th>Tài xế</th><th>Biển số</th>
        <th>Thời gian thuê</th><th>Thời gian trả</th><th>Hoạt động</th>
    </tr>
    <?php foreach ($ds_taxe as $xe): ?>
        <tr>
            <td><?= htmlspecialchars($xe['diemdon']) ?></td>
            <td><?= htmlspecialchars($xe['diemden']) ?></td>
            <td><?= htmlspecialchars($xe['ten_taixe']) ?></td>
            <td><?= htmlspecialchars($xe['bien_soxe']) ?></td>
            <td><?= htmlspecialchars($xe['tgthue']) ?></td>
            <td><?= htmlspecialchars($xe['tgtra']) ?></td>
            <td>
                <?php if (strtotime($xe['tgtra']) > time()): ?>
                    <button type="button" onclick="huyChuyen(<?= $xe['id'] ?>, 'co_taxe')" class="cancel-btn">Hủy</button>
                <?php else: ?>
                    Đã hoàn thành
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<h2>🚘 Lịch sử thuê xe tự lái</h2>
<table>
    <tr>
        <th>Tên xe</th><th>Loại xe</th><th>Biển số</th>
        <th>Thời gian thuê</th><th>Thời gian trả</th><th>Hoạt động</th>
    </tr>
    <?php foreach ($ds_tulai as $xe): ?>
        <tr>
            <td><?= htmlspecialchars($xe['ten_xe']) ?></td>
            <td><?= htmlspecialchars($xe['loai_xe']) ?></td>
            <td><?= htmlspecialchars($xe['bien_so']) ?></td>
            <td><?= htmlspecialchars($xe['tgthue']) ?></td>
            <td><?= htmlspecialchars($xe['tgtra']) ?></td>
            <td>
                <?php if (strtotime($xe['tgtra']) > time()): ?>
                    <button type="button" onclick="huyChuyen(<?= $xe['id'] ?>, 'xe_tulai')" class="cancel-btn">Hủy</button>
                <?php else: ?>
                    Đã hoàn thành
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
function huyChuyen(id, loai) {
    if (confirm("Bạn có chắc muốn hủy chuyến này?")) {
        fetch('lichsu_thuexe.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `huy_id=${id}&loai=${loai}`
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                location.reload();
            }
        })
        .catch(err => {
            alert('❌ Đã xảy ra lỗi.');
            console.error(err);
        });
    }
}
</script>
</body>
</html>