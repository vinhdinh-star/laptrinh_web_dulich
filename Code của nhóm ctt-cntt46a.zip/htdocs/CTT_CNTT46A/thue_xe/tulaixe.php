
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tìm xe</title>
    <style>
        body {
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            overflow-y: auto;
        }

        .form-container {
            position: sticky;
            top: 0;
            background-color: skyblue;
            padding: 15px;
            z-index: 999;
            text-align: center;
            border-bottom: 2px solid #ccc;
        }

        .vehicle-options {
            margin-top: 10px;
            font-size: 20px;
        }

        .vehicle-options select,
        .vehicle-options input[type="radio"],
        .vehicle-options button {
            margin: 0 10px;
            font-size: 18px;
        }

        .oto, .xe-7cho, .xe-16cho,.xe-2cho {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 500px;
            text-align: center;
            margin: 20px auto;
        }

        .oto img, .xe-7cho img, .xe-16cho img, .xe-2cho img {
            width: 80%;
            border-radius: 10px;
            margin: 10px 0;
        }

        button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
	<div>
		<input type="button" onclick="window.location.href='thuexe.php'" value="Quay lại trang thuê xe">

	<div>

    <!-- Form chọn loại xe -->
    <div class="form-container">
        <label><b style="font-size: 28px;">LOẠI XE (chọn 1):</b></label>
        <div class="vehicle-options">
            <input type="radio" id="trungchuyen" name="loaixe" value="trungchuyen"> Trung chuyển
            <select id="xe-trungchuyen">
                <option value="xe16cho">Xe 16 chỗ</option>
                <option value="xe29cho">Xe 29 chỗ</option>
            </select>

            <input type="radio" id="taxi" name="loaixe" value="taxi" checked> Taxi
            <select id="xehoi">
                <option value="oto">Xe 4 chỗ</option>
                <option value="xe7cho">Xe 7 chỗ</option>
            </select>

            <input type="radio" id="xe2cho" name="loaixe" value="xe2cho"> Xe 2 chỗ
            <select id="xe2cho">
                <option value="xemay">Xe máy</option>
                <option value="tayga">Tay ga</option>
            </select>

    
  </div>

            <button type="button" onclick="hienThiXe()">Tra</button>
        </div>
    </div>

    <!-- Các khối xe -->
    <div id="oto" style="display: none;">
        <!-- Thêm các div xe 4 chỗ ở đây (như bạn đã làm) -->
        <div class="oto">
            <h2>Toyota Yaris</h2>
            <img src="https://zingwheel.com/wp-content/uploads/2023/02/Danh-gia-chi-tiet-Toyota-yaris-ma-ban-nen-biet-Zingwheel-2.jpg" alt="Xe">
           <form id="datXeForm" action="ketnoitulaixe.php" method="POST">
                <div class="taixe">
                    <label>Thông Tin xe:</label>
                    <p><b>Giá thuê:</b> 800.000đ / ngày  cho thuê trong nội thành tỉnh Bình Định</p>
                    <p><b>Loại xe:</b> Hatchback 5 chỗ, số tự động</p>
                    <p><b>Biển số xe:</b> 77A-123.45</p>
                    <p><b>Tình trạng xe:</b> Xe mới, nội thất sạch đẹp, máy êm, đăng kiểm & bảo hiểm còn hạn</p>
                </div>
               <div class="form-group">
      <label>Số điện thoại</label>
      <input type="text" name="sdt"  value="" required>
    </div>

    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue"  value="2025-05-19T08:00" required min="<?= date('Y-m-d') ?>T00:00">
      <input type="datetime-local" name="tgtra" value="2025-05-20T08:00" style="margin-top: 10px;" required min="<?= date('Y-m-d') ?>T00:00">
    </div>
	
				<input type="hidden" name="ten_xe" value="Toyota Yaris">
  <input type="hidden" name="gia_thue" value="800000">
  <input type="hidden" name="loai_xe" value=" Hatchback 5 chỗ, số tự động">
  <input type="hidden" name="bien_so" value="77A-123.45">

			   <button type="submit">Xác nhận Đặt</button>
           
            </form>
        </div>
    </div>

    <div id="xe7cho" style="display: none;">
        <div class="xe-7cho">
            <h2> Honda CR-V </h2>
            <img src="https://cdn.24h.com.vn/upload/2-2023/images/2023-06-01/Cong-ty-Honda-Viet-Nam-trien-khai-chuong-trinh-khuyen-mai-Ruoc-CR-V-ngay-Qua-lien-tay-2-1685584166-425-width1000height667.jpg" alt="Xehd">
            <form id="datXeForm" action="ketnoitulaixe.php" method="POST">
                <div class="taixe">
                   <label>Thông Tin xe:</label>
                    <p><b>Giá thuê:</b>  1.100.000đ/ngày  cho thuê trong nội thành tỉnh Bình Định</p>
                    <p><b>Loại xe:</b> SUV 7 chỗ, số tự động, động cơ xăng tăng áp 1.5L</p>
                    <p><b>Biển số xe:</b> 77A-123.47</p>
                    <p><b>Tình trạng xe:</b> Xe đời 2022, nội thất sạch sẽ, máy móc vận hành êm ái, bảo dưỡng định kỳ đầy đủ</p>
                  </div>
				  
				  <div class="form-group">
      <label>Số điện thoại</label>
      <input type="text" name="sdt"  value="" required>
    </div>

    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue"  value="2025-05-19T08:00" required>
      <input type="datetime-local" name="tgtra" value="2025-05-20T08:00" style="margin-top: 10px;" required>
    </div>
      
  <input type="hidden" name="ten_xe" value="Honda CR-V">
  <input type="hidden" name="gia_thue" value="1100000">
  <input type="hidden" name="loai_xe" value="SUV 7 chỗ, số tự động">
  <input type="hidden" name="bien_so" value="77A-123.47">
  

   <button type="submit">Xác nhận Đặt</button>
  
</form>
        </div>
    </div>

    <div id="xe16cho" style="display: none;">
        <div class="xe-16cho">
            <h2> Mercedes Printer</h2>
            <img src="https://dulichviet.com.vn/images/bandidau/images/XE%20DU%20L%E1%BB%8ACH/Xe%2016%20CH%E1%BB%96/thue-xe-mercedes-printer-16-cho-tai-ha-noi-gia-re_du-lich-viet.png" alt="Xe 16 chỗ">
           <form id="datXeForm" action="ketnoitulaixe.php" method="POST">
                <div class="taixe">
                   <label>Thông Tin xe:</label>
                    <p><b>Giá thuê:</b> Khoảng 1.200.000đ/ngày cho thuê trong nội thành tỉnh Bình Định. Giá có thể thay đổi tùy theo lịch trình và thời gian thuê.</p>
                    <p><b>Loại xe:</b> Xe 16 chỗ, số sàn, động cơ diesel, phù hợp cho các chuyến du lịch, đưa đón sân bay hoặc công tác.</p>
                    <p><b>Biển số xe:</b> 77B-423.76</p>
                    <p><b>Tình trạng xe:</b> Xe đời mới, nội thất sạch sẽ, điều hòa hoạt động tốt, được bảo dưỡng định kỳ, đảm bảo an toàn và thoải mái cho hành khách.</p>
                </div>
				
				<div class="form-group">
      <label>Số điện thoại</label>
      <input type="text" name="sdt"  value="" required>
    </div>

    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue"  value="2025-05-19T08:00" required>
      <input type="datetime-local" name="tgtra" value="2025-05-20T08:00" style="margin-top: 10px;" required>
    </div>
				
				 <input type="hidden" name="ten_xe" value="Mercedes Printer">
  <input type="hidden" name="gia_thue" value="1200000">
  <input type="hidden" name="loai_xe" value="Xe 16 chỗ">
  <input type="hidden" name="bien_so" value="77B-423.76">
  

				
               <button type="submit">Xác nhận Đặt</button>
             
            </form>
        </div>
    </div>
	
	 <div class="xe-2cho" id="xe2cho_1" style="display: none;">
        <div class="xe-2cho">
            <h2> Air Blade</h2>
            <img src="https://th.bing.com/th/id/OIP.aYATH1hm-O0GsNLZnY3rWwHaE8?rs=1&pid=ImgDetMain" alt="Xe 16 chỗ">
             <form id="datXeForm" action="ketnoitulaixe.php" method="POST">
                <div class="taixe">
                   <label>Thông Tin xe:</label>
                    <p><b>Giá thuê:</b>Từ 120.000đ đến 250.000đ/ngày, cho thuê trong nội thành tỉnh Bình Định. Giá có thể thay đổi tùy theo lịch trình và thời gian thuê.</p>
                    <p><b>Loại xe:</b> Xe tay ga, động cơ 125cc hoặc 160cc, phù hợp cho cả nam và nữ.</p>
                    <p><b>Biển số xe:</b> 77B1-123.45 	</p>
                    <p><b>Tình trạng xe:</b>Xe đời 2022, được bảo dưỡng định kỳ, vận hành êm ái.</p>
                </div>
				
				<div class="form-group">
      <label>Số điện thoại</label>
      <input type="text" name="sdt"  value="" required>
    </div>

    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue"  value="2025-05-19T08:00" required>
      <input type="datetime-local" name="tgtra" value="2025-05-20T08:00" style="margin-top: 10px;" required>
    </div>
               
			   	 <input type="hidden" name="ten_xe" value="Air Blade">
  <input type="hidden" name="gia_thue" value="120000">
  <input type="hidden" name="loai_xe" value="Xe tay ga, động cơ 125cc">
  <input type="hidden" name="bien_so" value="77B1-123.45">

			   <button type="submit">Xác nhận Đặt</button>
          
            </form>
        </div>
    </div>
	
	 <div class="xe-2cho" id="xe2cho_2" style="display: none;">
        <div class="xe-2cho">
            <h2> Air Blade</h2>
            <img src="https://th.bing.com/th/id/OIP.aYATH1hm-O0GsNLZnY3rWwHaE8?rs=1&pid=ImgDetMain" alt="Xe 16 chỗ">
             <form id="datXeForm" action="ketnoitulaixe.php" method="POST">
                <div class="taixe">
                   <label>Thông Tin xe:</label>
                    <p><b>Giá thuê:</b>Từ 120.000đ đến 250.000đ/ngày, cho thuê trong nội thành tỉnh Bình Định. Giá có thể thay đổi tùy theo lịch trình và thời gian thuê.</p>
                    <p><b>Loại xe:</b> Xe tay ga, động cơ 125cc hoặc 160cc, phù hợp cho cả nam và nữ.</p>
                    <p><b>Biển số xe:</b> 77B1-543.99 	</p>
                    <p><b>Tình trạng xe:</b>Xe đời 2022, được bảo dưỡng định kỳ, vận hành êm ái.</p>
                </div>
				
				<div class="form-group">
      <label>Số điện thoại</label>
      <input type="text" name="sdt"  value="" required>
    </div>

    <div class="form-group">
      <label>Thời gian thuê</label>
      <input type="datetime-local" name="tgthue"  value="2025-05-19T08:00" required>
      <input type="datetime-local" name="tgtra" value="2025-05-20T08:00" style="margin-top: 10px;" required>
    </div>
               
			   	 <input type="hidden" name="ten_xe" value="Air Blade">
  <input type="hidden" name="gia_thue" value="120000">
  <input type="hidden" name="loai_xe" value="Xe tay ga, động cơ 125cc">
  <input type="hidden" name="bien_so" value="77B1-123.45">

			   <button type="submit">Xác nhận Đặt</button>
             
            </form>
        </div>
    </div>

    <script>
        function xacNhan() {
            alert("✅ Đặt xe thành công!");
        }

      
      function hienThiXe() {
    // Ẩn tất cả các khối xe
    document.getElementById("oto").style.display = "none";
    document.getElementById("xe7cho").style.display = "none";
    document.getElementById("xe16cho").style.display = "none";
    
    // Ẩn tất cả xe 2 chỗ
    document.getElementById("xe2cho_1").style.display = "none";
    document.getElementById("xe2cho_2").style.display = "none";

    const loaiXe = document.querySelector('input[name="loaixe"]:checked').value;

    if (loaiXe === "taxi") {
        const subType = document.getElementById("xehoi").value;
        if (subType === "oto") {
            document.getElementById("oto").style.display = "block";
        } else if (subType === "xe7cho") {
            document.getElementById("xe7cho").style.display = "block";
        }
    } else if (loaiXe === "trungchuyen") {
        const subType = document.getElementById("xe-trungchuyen").value;
        if (subType === "xe16cho") {
            document.getElementById("xe16cho").style.display = "block";
        } else {
            alert("Chưa có thông tin cho: " + subType);
        }
    } else if (loaiXe === "xe2cho") {
        // Hiển thị tất cả xe 2 chỗ có sẵn
        document.getElementById("xe2cho_1").style.display = "block";
        document.getElementById("xe2cho_2").style.display = "block";
    }
}

    </script>

</body>
</html>
