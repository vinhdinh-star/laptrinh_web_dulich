<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location:../TrangChu/main page/formDangNhap.php");
    echo "Bạn cần đăng nhập để đặt xe.";
    exit;
}

$user_id = $_SESSION['username'];
$_SESSION['diadiem'] = $_POST['diadiem'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sdt = trim($_POST['sdt'] ?? '');
    $tgthue = trim($_POST['tgthue'] ?? '');
    $tgtra = trim($_POST['tgtra'] ?? '');
    $ten_xe = trim($_POST['ten_xe'] ?? '');
    $gia_thue = trim($_POST['gia_thue'] ?? '');
    $loai_xe = trim($_POST['loai_xe'] ?? '');
    $bien_so = trim($_POST['bien_so'] ?? '');

    if ($sdt === '' || $tgthue === '' || $tgtra === '' || $ten_xe === '' || $gia_thue === '' || $loai_xe === '' || $bien_so === '') {
        echo "Vui lòng nhập đầy đủ thông tin.";
        exit;
    }

    try {
        // Kiểm tra số điện thoại đã được dùng bởi chính người dùng này chưa
        $stmt = $pdo->prepare("SELECT * FROM xe_tulai WHERE sdt = ? AND user_id = ?");
        $stmt->execute([$sdt, $user_id]);

        if ($stmt->rowCount() > 0) {
            echo "Số điện thoại đã được sử dụng để đặt trước đó.";
            exit;
        }

        // Kiểm tra trùng lịch
        $stmt = $pdo->prepare("
            SELECT * FROM xe_tulai 
            WHERE bien_so = ? 
              AND NOT (
                    tgtra <= ? OR tgthue >= ?
              )
        ");
        $stmt->execute([$bien_so, $tgthue, $tgtra]);

        if ($stmt->rowCount() > 0) {
            echo "Xe này đã được đặt trong khoảng thời gian bạn chọn.";
            exit;
        }

        // Chèn dữ liệu đặt xe mới
        $stmt = $pdo->prepare("
            INSERT INTO xe_tulai (user_id, sdt, tgthue, tgtra, ten_xe, gia_thue, loai_xe, bien_so) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $sdt, $tgthue, $tgtra, $ten_xe, $gia_thue, $loai_xe, $bien_so]);

        // Trả về kết quả thành công và chuyển hướng
        echo "<script>alert('Đặt xe thành công!'); window.location.href='tulaixe.php';</script>";
        exit;

    } catch (PDOException $e) {
        echo "Lỗi kết nối CSDL: " . $e->getMessage();
    }
}
?>
