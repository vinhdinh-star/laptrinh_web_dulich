<?php
require 'connect.php';
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['username'])) {
        header("Location:../TrangChu/main page/formDangNhap.php");
        exit(); 
    }

// Lấy user và thông tin điểm đón/trả từ SESSION
$user_id = $_SESSION['username'];
$diemdon = $_SESSION['diemdon'] ?? '';
$diemden = $_SESSION['diemden'] ?? '';
$tgthue = $_SESSION['tgthue'] ?? '';
$tgtra = $_SESSION['tgtra'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lấy thông tin xe có tài xế từ form
    $sodt = trim($_POST['sodt'] ?? '');
    $ten_taixe = trim($_POST['ten_taixe'] ?? '');
    $gias = trim($_POST['gias'] ?? '');
    $socho_ngoi = trim($_POST['socho_ngoi'] ?? '');
    $bien_soxe = trim($_POST['bien_soxe'] ?? '');
    $kinhnghiem = trim($_POST['kinhnghiem'] ?? '');

    // Kiểm tra thiếu dữ liệu
    if ($sodt === '' || $ten_taixe === '' || $gias === '' || $socho_ngoi === '' || $bien_soxe === '' || $kinhnghiem === '') {
        echo "Vui lòng nhập đầy đủ thông tin.";
        exit;
    }

    try {
        // Kiểm tra xe có bị trùng thời gian thuê
        $stmt = $pdo->prepare("
            SELECT * FROM co_taxe 
            WHERE bien_soxe = ? 
              AND NOT (
                    tgtra <= ? OR tgthue >= ?
              )
        ");
        $stmt->execute([$bien_soxe, $tgthue, $tgtra]);

        if ($stmt->rowCount() > 0) {
            echo "🚗 Xe này đã được đặt trong khoảng thời gian bạn chọn.";
            exit;
        }

        // Lưu vào cơ sở dữ liệu
        $stmt = $pdo->prepare("
            INSERT INTO co_taxe (user_id, sodt, tgthue, tgtra, ten_taixe, gias, kinhnghiem, bien_soxe, diemdon, diemden, socho_ngoi) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $sodt, $tgthue, $tgtra, $ten_taixe, $gias, $kinhnghiem, $bien_soxe, $diemdon, $diemden, $socho_ngoi]);

        echo "<script>alert('🚗 Đặt xe có tài xế thành công!'); window.location.href='timxe.php';</script>";
        
        exit;
    } catch (PDOException $e) {
        echo "Lỗi CSDL: " . $e->getMessage();
    }
}
?>