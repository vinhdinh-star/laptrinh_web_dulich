-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2025 at 07:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotrodulich`
--

-- --------------------------------------------------------

--
-- Table structure for table `xe_tulai`
--

CREATE TABLE `xe_tulai` (
  `user_id` varchar(50) NOT NULL,
  `diadiem` text DEFAULT NULL,
  `sdt` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `tgthue` datetime DEFAULT NULL,
  `tgtra` datetime DEFAULT NULL,
  `ten_xe` text NOT NULL,
  `gia_thue` int(25) NOT NULL,
  `loai_xe` text NOT NULL,
  `bien_so` varchar(25) NOT NULL,
  `id` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `xe_tulai`
--

INSERT INTO `xe_tulai` (`user_id`, `diadiem`, `sdt`, `tgthue`, `tgtra`, `ten_xe`, `gia_thue`, `loai_xe`, `bien_so`, `id`) VALUES
('', NULL, NULL, '2025-05-19 08:00:00', '2025-05-20 08:00:00', 'Toyota Yaris', 800000, 'Hatchback 5 chỗ, số tự động', '77A-123.45', NULL),
('', NULL, NULL, '2025-05-23 01:02:00', '2025-05-30 02:03:00', 'Honda CR-V', 1100000, 'SUV 7 chỗ, số tự động', '77A-123.47', NULL),
('', NULL, NULL, '2025-05-19 08:00:00', '2025-05-20 08:00:00', 'Air Blade', 120000, 'Xe tay ga, động cơ 125cc', '77B1-123.45', NULL),
('', NULL, '0977846880', '2025-05-19 08:00:00', '2025-05-20 08:00:00', 'Mercedes Printer', 1200000, 'Xe 16 chỗ', '77B-423.76', NULL),
('', NULL, '3243243221', '2025-05-19 08:00:00', '2025-05-20 08:00:00', 'Toyota Yaris', 800000, 'Hatchback 5 chỗ, số tự động', '77A-123.45', NULL),
('', NULL, '0368877633', '2025-05-19 08:00:00', '2025-05-20 08:00:00', 'Honda CR-V', 1100000, 'SUV 7 chỗ, số tự động', '77A-123.47', NULL),
('', NULL, '0934887880', '2025-06-24 08:00:00', '2025-06-29 08:00:00', 'Air Blade', 120000, 'Xe tay ga, động cơ 125cc', '77B1-123.45', NULL),
('', NULL, '1234567890', '2025-05-29 08:00:00', '2025-05-31 08:00:00', 'Toyota Yaris', 800000, 'Hatchback 5 chỗ, số tự động', '77A-123.45', NULL),
('', NULL, '1223133546', '2025-07-23 08:00:00', '2025-08-02 08:00:00', 'Honda CR-V', 1100000, 'SUV 7 chỗ, số tự động', '77A-123.47', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
