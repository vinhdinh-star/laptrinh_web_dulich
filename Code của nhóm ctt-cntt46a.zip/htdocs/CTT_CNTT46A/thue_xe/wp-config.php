<?php

define('DB_NAME', 'if0_39104107_ungdungdulich');

define('DB_USER', 'if0_39104107');

define('DB_PASSWORD', 'qBVXBbTACJ9Xk');

define('DB_HOST', 'sql111.infinityfree.com');

define('DB_CHARSET', 'utf8mb4');

define('DB_COLLATE', '' );
?>