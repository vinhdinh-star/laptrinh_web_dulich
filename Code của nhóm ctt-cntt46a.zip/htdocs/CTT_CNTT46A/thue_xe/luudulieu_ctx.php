<?php
session_start();

// Lưu thông tin chuyến đi vào SESSION
$_SESSION['diemdon'] = $_POST['diemdon'] ?? '';
$_SESSION['diemden'] = $_POST['diemden'] ?? '';
$_SESSION['tgthue'] = $_POST['tgthue'] ?? '';
$_SESSION['tgtra'] = $_POST['tgtra'] ?? '';

// Chuyển sang trang nhập thông tin tài xế
header("Location: timxe.php");
exit;
?>