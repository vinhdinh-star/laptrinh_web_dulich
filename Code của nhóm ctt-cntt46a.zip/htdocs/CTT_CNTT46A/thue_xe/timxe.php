

<!DOCTYPE html>
<html>
<head>
    <title>Tìm xe</title>
    <style>
        background-color: #f0f0f0;    margin: 0; padding: 0;  font-family: Arial, sans-serif;   overflow-y: auto;
        }

        .form-container {
            position: sticky;
            top: 0;
            background-color: skyblue;
            padding: 15px;
            z-index: 999;
            text-align: center;
            border-bottom: 2px solid #ccc;
        }

        .vehicle-options {
            margin-top: 10px;
            font-size: 20px;
        }

        .vehicle-options select,
        .vehicle-options input[type="radio"],
        .vehicle-options button {       margin: 0 10px;     font-size: 18px;
        }

        .content {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .xe-card, .xe-Gab, .xe-16cho {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 500px;
            text-align: center;
            overflow-y: auto;
        }

        .xe-card img, .xe-Gab , .xe-16cho img {   width: 80%;    border-radius: 10px;   margin: 10px 0;
        }

        .taixe {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 16px;
            margin: 10px 0;
            background-color: #f9f9f9;
            text-align: left;
        }

        .taixe label {
            font-weight: bold;
            font-size: 16px;
            display: block;
            margin-bottom: 6px;
        }

        .taixe b {    font-size: 18px;   color: #2c3e50;
        }

        .taixe p {   margin: 4px 0;   font-size: 15px;
        }
        button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

	
    </style>
</head>
<body>
<div>
		<input type="button" onclick="window.location.href='thuexe.php'" value="Quay lại trang thuê xe">

	<div>
     <!-- Form chọn loại xe -->
    <div class="form-container">
        <label><b style="font-size: 28px;">LOẠI XE (chọn 1):</b></label>
        <div class="vehicle-options">
            <input type="radio" id="trungchuyen" name="loaixe" value="trungchuyen" onclick="chonLoaiXe()"> Trung chuyển
            <select id="xe-trungchuyen" onchange="hienThiXe()">
                <option value="xe16cho">Xe 16 chỗ</option>
                <option value="xe29cho">Xe 29 chỗ</option>
            </select>

            <input type="radio" id="taxi" name="loaixe" value="taxi" onclick="chonLoaiXe()" checked> Taxi
            <select id="xe-taxi" onchange="hienThiXe()">
                <option value="XanhSM">Xanh SM (điện)</option>
                <option value="Grab">Grab (xăng)</option>
            </select>

            <input type="radio" id="xe2cho" name="loaixe" value="xe2cho" onclick="chonLoaiXe()"> Xe 2 chỗ
            <select id="xe-2cho" onchange="hienThiXe()">
                <option value="xemay">Xe máy</option>
                <option value="tayga">Tay ga</option>
            </select>

              <button type="button" onclick="hienThiXe()">Tra</button>
        </div>
    </div>
	
<div id="XanhSM" style="display: none;">
<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; padding: 20px;" id="chonLoaiXe" onchange="hienThiXe()">
    <div class="xe-card">
        <h2>Xe điện Xanh SM</h2>
        <img  src="https://cdnphoto.dantri.com.vn/CLcU5991cxoZFn2UZFkpDgq-Du8=/zoom/1200_630/2023/04/14/cac-cach-goi-xe-taxi-dien-xanh-sm-anh2-crop-1681461555438.jpeg" alt="Xe Xanh SM">
        
        <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Đặng Tiến Hoàng</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0356565678</p>
				<p>kinh nghiệm: 5 năm</p>
				<p>giá: 150.000đ</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 4(chỗ)</p>
			</div>
           
		   	<input type="hidden" name="ten_taixe" value="Đặng Tiến Hoàng">
  <input type="hidden" name="sodt" value="0356565678">
  <input type="hidden" name="kinhnghiem" value="5 năm">
  <input type="hidden" name="socho_ngoi" value="4 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77A-580.11">
  
  

            <button type="submit">Xác nhận Đặt</button>
          
        </form>
    </div>

	

	 <div class="xe-card">
        <h2>Xe điện Xanh SM</h2>
        <img style="width: 63%; border-radius: 10px; margin: 10px 0;"  src="https://cafebiz.cafebizcdn.vn/162123310254002176/2023/4/15/nlh5131-1681465454424489555661-1681527006413-16815270077021995839508.jpg" alt="Xe Xanh SM">
        
        <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Chu Tước Tử</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0357565678</p>
				<p>kinh nghiệm: 2 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 5(chỗ)</p>
			</div>
      
	  	<input type="hidden" name="ten_taixe" value="Chu Tước Tử">
  <input type="hidden" name="sodt" value="0357565678">
  <input type="hidden" name="kinhnghiem" value="2 năm">
  <input type="hidden" name="socho_ngoi" value="5 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77A-586.11">

           <button type="submit">Xác nhận Đặt</button>
          
        </form>
    </div>


	<div class="xe-card">
        <h2>Xe điện Xanh SM</h2>
        <img style="width: 46%; border-radius: 10px; margin: 1px 0;"  src="https://banggiavinfast.vn/wp-content/uploads/2023/12/Vinfast-vf9-xanh-rental-800x800.jpg" alt="Xe Xanh SM">
        
        <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Chu Dật Tài</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0934867234</p>
				<p>kinh nghiệm: 8 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 7(chỗ)</p>
			</div>
			
			 	<input type="hidden" name="ten_taixe" value="Chu Dật Tài">
  <input type="hidden" name="sodt" value="0934867234">
  <input type="hidden" name="kinhnghiem" value="8 năm">
  <input type="hidden" name="socho_ngoi" value="7 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77L-123.11">

            <button type="submit">Xác nhận Đặt</button>
           
        </form>
    </div>


	<div class="xe-card">
        <h2>Xe điện Xanh SM</h2>
        <img style="width: 46%; border-radius: 10px; margin: 1px 0;"  src="https://banggiavinfast.vn/wp-content/uploads/2023/12/Vinfast-vf9-xanh-rental-800x800.jpg" alt="Xe Xanh SM">
        
        <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Vương Bình</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0863486723</p>
				<p>kinh nghiệm: 11 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 7(chỗ)</p>
			</div>
            
			<input type="hidden" name="ten_taixe" value="Vương Bình">
  <input type="hidden" name="sodt" value="0863486723">
  <input type="hidden" name="kinhnghiem" value="11 năm">
  <input type="hidden" name="socho_ngoi" value="7 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77H-129.76">

                        <button type="submit">Xác nhận Đặt</button>

           
        </form>
    </div>
	
	 <div class="xe-card">
        <h2>Xe điện Xanh SM</h2>
        <img  src="https://cdnphoto.dantri.com.vn/CLcU5991cxoZFn2UZFkpDgq-Du8=/zoom/1200_630/2023/04/14/cac-cach-goi-xe-taxi-dien-xanh-sm-anh2-crop-1681461555438.jpeg" alt="Xe Xanh SM">
        
        <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Trần Minh Hiếu</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0356565670</p>
				<p>kinh nghiệm: 6 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 4(chỗ)</p>
			</div>
          
			 	<input type="hidden" name="ten_taixe" value="Trần Minh Hiếu">
  <input type="hidden" name="sodt" value="0356565670">
  <input type="hidden" name="kinhnghiem" value="6 năm">
  <input type="hidden" name="socho_ngoi" value="4 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77C-970.72">


                       <button type="submit">Xác nhận Đặt</button>

           
        </form>
    </div>
</div>	
</div>


<div id="Grab" style="display: none; padding: 20px;
            margin: 10px 0;  border-radius: 10px;
            width: 600px;">

	<div class="xe-Gab">
        <h2>Xe xăng Grab</h2>
        <img  src="https://th.bing.com/th/id/OIP.u9dWLOZTNnpaLXynZslGfgHaEE?rs=1&pid=ImgDetMain" style="width:300px; height:150px;" alt="Xe Xanh SM">
        
       <form  action="ketnoicotaixe.php" method="POST">
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Bình Vàng</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0356545678</p>
				<p>kinh nghiệm: 6 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 4(chỗ)</p>
			</div>
            
			 	<input type="hidden" name="ten_taixe" value="Bình Vàng">
  <input type="hidden" name="sodt" value="0356545632">
  <input type="hidden" name="kinhnghiem" value="6 năm">
  <input type="hidden" name="socho_ngoi" value="4 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77D-100.00">
	
                        <button type="submit">Xác nhận Đặt</button>

            
        </form>
    </div>
</div>


<div id="xe16cho" style="display: none;">

	<div class="xe-16cho">
        <h2>Xe 16 chổ</h2>
        <img  src="https://dulichviet.com.vn/images/bandidau/images/XE%20DU%20L%E1%BB%8ACH/Xe%2016%20CH%E1%BB%96/thue-xe-mercedes-printer-16-cho-tai-ha-noi-gia-re_du-lich-viet.png" alt="Xe Xanh SM">
        
       <form  action="ketnoicotaixe.php" method="POST" >
			<div class="taixe">
				<label>Tài xế:</label>
				<b type="text" name="name">Trịnh Trần Phương Tuấn</b>
				<p style="font-size: 17px;" type="int" name="sdt">Số điện thoại: 0356545678</p>
				<p>kinh nghiệm: 3 năm</p>
				<p type="text" name="socho_ngoi">số chổ ngồi: 16(chỗ)</p>
			</div>

			 	<input type="hidden" name="ten_taixe" value="Trịnh Trần Phương Tuấn">
  <input type="hidden" name="sodt" value="0432423432">
  <input type="hidden" name="kinhnghiem" value="3 năm">
  <input type="hidden" name="socho_ngoi" value="16 chỗ">
  <input type="hidden" name="gias" value="150000">
  <input type="hidden" name="bien_soxe" value="77A-555.51">



             <button type="submit">Xác nhận Đặt</button>
            
        </form>
    </div>
</div>

    <script>
      function xacNhan(event) {
    event.preventDefault();
    alert("✅ Đặt xe thành công!");
}

        

		function chonLoaiXe() {
            // Đây là nơi bạn có thể làm thêm logic để hiển thị select tương ứng
            // VD: ẩn hiện các <select> tùy vào radio đang chọn
        }

         function hienThiXe() {
    const selectedVehicle = document.querySelector('input[name="loaixe"]:checked').value;

    // Ẩn tất cả các nhóm xe trước
    document.getElementById("XanhSM").style.display = "none";
    document.getElementById("Grab").style.display = "none";
    document.getElementById("xe16cho").style.display = "none";
    // Nếu bạn thêm các div khác như "xe29cho", "xe2cho"... cũng ẩn luôn ở đây

    let detail = "";

    if (selectedVehicle === "taxi") {
        detail = document.getElementById("xe-taxi").value;
        if (detail === "XanhSM") {
            document.getElementById("XanhSM").style.display = "block";
        } else if (detail === "Grab") {
            document.getElementById("Grab").style.display = "block";
        }
    } else if (selectedVehicle === "trungchuyen") {
        detail = document.getElementById("xe-trungchuyen").value;
        if (detail === "xe16cho") {
            document.getElementById("xe16cho").style.display = "block";
        }
        // Bạn có thể thêm div cho xe29cho tương tự nếu có
    } else if (selectedVehicle === "xe2cho") {
        detail = document.getElementById("xe-2cho").value;
        // Tùy loại xe bạn có thể tạo thêm div như "xemay", "tayga" và xử lý ở đây
        alert("Hiện chưa hỗ trợ hiển thị chi tiết cho loại xe 2 chỗ: " + detail);
    }
}

	
    </script>
</body>
</html>
